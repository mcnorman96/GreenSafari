<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package GeneratePress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

get_header(); ?>

	<div id="primary" <?php generate_content_class();?>>
		<main id="main" <?php generate_main_class(); ?>>
			<?php
			/**
			 * generate_before_main_content hook.
			 *
			 * @since 0.1
			 */
			do_action( 'generate_before_main_content' );

			?>
				<div class="bbh-outer-wrapper" id="bbh-content">
					<?php
					if( have_rows('flex_content', 984) ): ?>

						<div class="flexible-field-wrapper">
							<?php // loop through the rows of data
							while ( have_rows('flex_content', 984) ) : the_row();

								// save layout name as var
								$slug = get_row_layout();
								// check if layout exist in import folder
								if( file_exists( get_theme_file_path("/include/flexible-content/import/{$slug}.php") ) ) {
									include( get_theme_file_path("/include/flexible-content/import/{$slug}.php") );
								}

							endwhile; // END while have_rows() ?>
						<?php // END div.flexible-field-wrapper ?>
					<?php else :
						// no layouts found
					endif;
					?>
					<?php
          $queried_object = get_queried_object();
          $taxonomy = $queried_object->taxonomy;
          $term_id = $queried_object->term_id;
          $banner = get_field('rejsetype_banner', $taxonomy . '_' . $term_id);
          $velkommen = get_field('rejsetype_txbox', $taxonomy . '_' . $term_id);
				  $velkommencta = get_field('rejsetype_cta', $taxonomy . '_' . $term_id);
					$rejsekort = get_field('rejsekort', $taxonomy . '_' . $term_id);
					  ?>
					<div class="flexible-inner-section bbh-inner-section singleposts">
						<div class="singlebg"></div>
							<div class="rejsebannerbillede lazyload" data-bgset="<?php echo $banner['url'] ?>"><div class="imgbg"></div></div>
    						<div class="singlepost">
                  <div class="sektion destionationervelkommen">
                    <div class="grid-container">
                      <div class="row">
                        <div class="col-md-6">
                          <?php
                            echo $velkommen;
                           ?>
                           <?php if ($velkommencta) :
                             ?>
                             <div class="cta">
                               <a class="btn-yellow" href="<?php echo $velkommencta['url']; ?>"> <?php echo $velkommencta['title']; ?> </a>
                             </div>
                             <?php
                           endif; ?>

                        </div>
                        <div class="col-md-6">
													<?php if ($rejsekort): ?>
														<div class="rejsekort">
	                            <img class="lazyload" src="<?php echo $rejsekort['url']; ?>" alt="">
	                          </div>
													<?php endif; ?>

                        </div>
                      </div>
                    </div>
                  </div>
									<?php if( have_rows('rejsetype_populaere_ture', $taxonomy . '_' . $term_id) ):
											// loop through the rows of data
											while ( have_rows('rejsetype_populaere_ture', $taxonomy . '_' . $term_id) ) : the_row();
											$trips = get_sub_field('trips');
											$tripslink = get_sub_field('link');
											$tripstx = get_sub_field('txbox');
											$taxs = get_sub_field('trips');
									?>
									<?php if ($tripstx): ?>
									<div class="sektion popularrejsetypetx">
											<div class="grid-container second">
												<div class="row">
													<div class="col-md-6">
														<?php echo $tripstx; ?>
													</div>
	                        <?php if ($tripslink): ?>
	                          <div class="col-md-6">
	  													<a class="btn-green" href="<?php echo $tripslink['url'];  ?>"><?php echo $tripslink['title']; ?>hej</a>
	  												</div>
	                        <?php endif; ?>
						         </div>
	                  </div>
	                </div>
									<?php endif; ?>
									<?php
										 endwhile;
									endif;
									?>
                <div class="sektion popularrejsetype">
                  <div class="grid-container">
										<div class="row">
											<div class="col-sm-12">
												<h2>Alle <?php single_cat_title() ?> safarier</h2>
												<?php
	                      $terms = get_query_var('term');
			                    $args = array(
			                        'posts_per_page' => -1,
			                        'post_type'      => 'trips',
			                        'orderby'        => 'title',
			                        'order'          => 'ASC',
	                            'tax_query' => array(
	                                array(
	                                'taxonomy' => 'rejsetype',
	                                'field'    => 'slug',
	                                'terms'    => $terms,
	                                       ),
	                               ),
			                        'paged' => 1,
			                    );

			                    $query = new WP_Query($args);
			                    $postsdisplayed = $query->found_posts;
			                    $posts = $query->posts;

													if($posts): ?>
	                        <div class="rejser">
	                            <div id="posts" data-count="<?php echo ceil($postsdisplayed); ?>">
	                                <?php
	                                foreach($posts as $post):?>
	                                <?php setup_postdata($post);?>
	                                <div class="rejse">
																		<a href="<?php echo the_permalink() ?>">
	                                    <div class="img lazyload" data-bgset="<?php echo get_the_post_thumbnail_url('','medium') ?>"></div>
	                                    <div class="bg"></div>
	                                    <div class="details">
	                                        <h3 class="name"><?php the_title(); ?></h3>
	                                        <?php if(get_field('safari_description')) : ?><span class="description"><?php the_field('safari_description') ?></span><?php endif; ?>
	                                        <a href="<?php echo the_permalink() ?>"><span class="icon-pil-ned hoejre"></span>Undersøg safaritypen</a>
	                                    </div>
																		</a>
	                                </div>
	                                <?php endforeach; ?>
	                                <?php wp_reset_postdata(); ?>
	                                <div class="placeholder"></div>
	                                <div class="placeholder"></div>
	                            </div>
	                        </div>
			                    <?php endif;
												?>
											</div>
	                  </div>
									</div>
								</div>
							</div>
    				</div>
    			</div>
			<?php
			/**
			 * generate_after_main_content hook.
			 *
			 * @since 0.1
			 */
			do_action( 'generate_after_main_content' );
			?>
		</main><!-- #main -->
	</div><!-- #primary -->

	<?php
	/**
	 * generate_after_primary_content_area hook.
	 *
	 * @since 2.0
	 */
	do_action( 'generate_after_primary_content_area' );

	generate_construct_sidebars();


	get_footer();
