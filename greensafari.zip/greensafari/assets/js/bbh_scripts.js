(function($) {
    function loop() {
      if (window.matchMedia('(max-width: 1200px)').matches) {
        $('.frontpagecontainer .icon-pil-ned').animate({'bottom': '50px'}, {
            duration: 1000,
            complete: function() {
                $('.frontpagecontainer .icon-pil-ned').animate({bottom: 25}, {
                    duration: 1000,
                    complete: loop});
            }});
      } else {
        $('.frontpagecontainer .icon-pil-ned').animate({'bottom': '75px'}, {
            duration: 1000,
            complete: function() {
                $('.frontpagecontainer .icon-pil-ned').animate({bottom: 50}, {
                    duration: 1000,
                    complete: loop});
            }});
      }

    }
    loop();
    $(document).ready(function () {
      $(".site-header .main-navigation .headerflex li a:not(ul li ul li a)").after("<span class='icon-pil-ned'></span>");
      $("#mobile-header li a:not(ul li ul li a)").after("<span class='icon-pil-ned'></span>");
      $(".inside-header").before("<div class='headerbg'></div>");
      $("#mobile-header .inside-navigation").before("<div class='headerbg'></div>");


    });

    $('.standardimgs').slick({
      infinite: true,
      slidesToShow: 3,
      slidesToScroll: 2,
      responsive: [
    {
      breakpoint: 992,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        infinite: true,
      }
    },
    {
      breakpoint: 650,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
        arrows: false,
        dots: true
      }
  },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        dots: true
      }
    }
  ]
    });
    //show inner slider on main slider click
    $('.standardimg').click(function() {
        var slideNumber = $(this).data('number')
        $(this).parents('.standardimgs').siblings('div[data-number='+slideNumber+']').show()
        $('.inner-slider').each(function() {
            $(this).slick({
              infinite: true,
              slidesToShow: 1,
              slidesToScroll: 1
            })
        })
    })
    $('.singleposts .modal-slider .icon-minus').click(function() {
        $(this).parents('.modal-slider').hide()
        $('.inner-slider').each(function() {
            $(this).slick('unslick');
        })

    })


    $('.safariimg').slick({
      vertical: true,
      //verticalSwiping: true,
      dots:false
    });

    $(document).ready(function (){
        var id = $('.destinationmenu.current').attr('data-id');
        $('.destinationsboks').css("display", "none");
        $('.destinationsboks[data-id=' + id +']').addClass('current').css("display","block");
    });

    $(document).ready(function () {
        $('.destinationerquery').on('click', 'a', function () {
            $('.destinationmenu.current').not($(this).closest('a').addClass('current')).removeClass('current');
            // fade out all open subcontents
            $('.destinationsboks:visible').hide(600);
            // fade in new selected subcontent
            $('.destinationsboks[data-id=' + $(this).attr('data-id') + ']').show(600);
        });
    });

    /*========================================
    =                BLOG AJAX               =
    ========================================*/
    //Save ajax as function
    function runAjax() {
        var filter = $('#filter') // Get form
        var postWrapper = $('.posts') // Get markup grid container
        var tripwrapper = $('.c3-safari .rejser, .c3-voresture .rejser, .c3-tilkoeb .rejser')
        $.ajax({
            url:filter.attr('action'), // Get form action
            data:filter.serialize(), // Get form data
            type:filter.attr('method'), // Get form method
            beforeSend:function(){
                postWrapper.animate({opacity:0},50) // Fade markup out
                tripwrapper.animate({opacity:0},50) // Fade markup out
            },
            success:function(data){
                if(data.append_markup)
                postWrapper.append(data.append_markup)
                if(data.trip_markup)
                tripwrapper.html(data.trip_markup)

            },
            complete:function(){
                overlayphp()
                loadmore();
                postWrapper.delay(50).animate({opacity:1},50) // Fade markup in
                tripwrapper.delay(50).animate({opacity:1},50) // Fade markup in

            },
            error:function(error){
                postWrapper.delay(50).animate({opacity:1},50) // Fade markup in
                tripwrapper.delay(50).animate({opacity:1},50) // Fade markup in
                console.log(error) // Console log error
            }
        })
    }
    //query filter
    $(document).on('submit','#filter',function(e) {
        e.preventDefault()
        $('input[name=offset]').val(0)
        var activePage = $('.archive-pagination span:first-of-type')
        $(activePage).addClass('current')
        $(activePage).siblings().each(function() {
            $(this).removeClass()
        })
        runAjax()
    })

    $('.c3-safari #filter, .c3-voresture #filter, .c3-tilkoeb #filter').change(function() {
        loadmore();
        runAjax();

    })
    $('.c3-safari #filter label, .c3-voresture #filter label, .c3-tilkoeb #filter label').on('click',function() {
        $(this).addClass('current')
        if (window.matchMedia('(max-width: 992px)').matches) {
          $('.c3-safari #filter label, .c3-tilkoeb #filter label, .c3-voresture #filter label').parents('.slick-slide').siblings().children('div').children('label').each(function() {
              $('.c3-safari #filter label, .c3-tilkoeb #filter label, .c3-voresture #filter label').removeClass('current')
          })
          console.log('click');
        } else {
          $(this).siblings().each(function() {
              $(this).removeClass('current')
          })
          console.log('clicked');
        }

    });

    //Reset when 'all' is pressed
    $('#resetform').click(function() {
      $('#filter input').each(function () {
        $(this).removeAttr("checked");
      })
      $(this).attr('checked', true)
      runAjax()
    })

        //Label click = input click
    $('#filter label, #filter-tags label').click(function() {
      $(this).siblings('input').click()
      $(this).parent().siblings().children('input').attr('checked',false)
    })


  function loadmore() {
      var post_count = $('#posts').data('count');
      var page = 2;
      var ajaxurl = $('#filter').attr('action');


      if (parseInt(post_count) >= 7) {
      counter = post_count;
      $('#load_more').show();

      }
      else {
      counter = 0;
      $('#load_more').hide();
      }

          $('#load_more').unbind('click').click(function(){
      		var data = {
      			'action': 'my_action',
      			'page': page,
            'trip_ids': $('#filter label.current input').val(),
      		};

        		$.post(ajaxurl, data, function(response) {
              $('#posts').append(response);
              $('#load_more').hide();

              if (post_count == page || post_count < 1) {
                  $('#load_more').hide();
              }
              page++;
        		});
      });
};
loadmore();

//Header scroll

window.onscroll = function() {scrollFunction()};

function scrollFunction() {

  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
    $(".headerbg").css({
      "background-color": "#1D1F09",
      "opacity" : "0.8"
    });
    $(".site-logo").width( '90px' );
    $(".site-header .inside-header.grid-container.grid-parent").css({
      "padding": "10px 0"
    });
  } else {
    $(".site-logo").width( 'auto' );
    $(".site-header .inside-header.grid-container.grid-parent").css({
      "padding": "40px 0"
    });
    $(".headerbg").css({
      "opacity" : "1",
      "background-color": "unset"
    });
  }
}



    $(".programcontentheader").click(function(){
        $(this).parents('.programmer').addClass('current')
        $(this).parents('.programmer').siblings().each(function() {
            $(this).removeClass('current')
        })

      if ($(this)) {
          $(".programmer.current .programcontentp").slideToggle(750, function() {
            if ($(this).is(":visible")) {
                 $(".programmer.current #icon").addClass('icon-minus')
                 $(".programmer.current #icon").removeClass('icon-plus')
            } else {
                 $(".programmer.current #icon").addClass('icon-plus')
                 $(".programmer.current #icon").removeClass('icon-minus')
            }
        });

      } else {
          $(this).hide();
      }
    });

    $(".search .icon-soeg").click(function(){
        $(this).addClass('current')
        $(this).siblings().each(function() {
            $(this).removeClass('current')
        })
      if ($(this)) {
          $(".searchandoffer form").slideToggle(750).css({
              "display" : "flex"
          });
      } else {
          $(this).hide();
      }
    });

    $('.c3-tilkoeb .safariimg').each(function() {
        $(this).slick('unslick');
    });

function overlayphp() {
    $(".c3-tilkoeb a.overlayphp").click(function(){
        $(this).parents('.rejse').addClass('current')
        $(this).parents('.rejse').siblings().each(function() {
            $(this).removeClass('current')
        });
        console.log('cliocked');
        $('.c3-tilkoeb .safariimg').slick({
          vertical: true,
          verticalSwiping: true,
          dots:false
        });
        $('.c3-tilkoeb .overlayclose').click(function(){
            $('.rejse').removeClass('current')
        });
    });
}
    overlayphp();

        if($(document).attr('title') == 'Tilkøb - greensafari'){
          $('.c3-tilkoeb form label.current input', function(){
              $('.c3-tilkoeb form label.current input').attr('checked', true)
              runAjax();

          });
        }

    $(".c3-safaridestinations #loadmore").click(function(){
          $('.rejses.showhide').css({
              'display' : 'block'
          });
          $(this).hide();
      });


          if (window.matchMedia('(max-width: 992px)').matches) {
            $('.c3-safaridestinations .rejsers, .c3-choosetrips .rejsers').slick({
              arrows: false,
              dots:true,
              infinite: true,
              slidesToShow: 1,
              slidesToScroll: 1,
              swipe: true,
              swipeToSlide: true
            });
            $('.labels').slick({
              arrows: true,
              variableWidth: true,
              swipeToSlide: true,
              infinite: false,
              dots:false
            });

          }

          $(".contactform").click(function(){
                $('.contactsafari').css({
                    'display' : 'block'
                });
                $('.inside-header').css({
                    'display' : 'none'
                });
                $('#mobile-header .menu-toggle .mobile-menu, .navigation-branding img, .site-logo.mobile-header-logo img, .searchandoffer').hide();
            });
            $(".contactsafari .icon-minus").click(function(){
                  $('.contactsafari').css({
                      'display' : 'none'
                  });
                  $('.inside-header').css({
                      'display' : 'block'
                  });
                  $(".site-header .main-navigation .grid-container").css({
                    'margin-top' : '20px;'
                  })
                $('#mobile-header .menu-toggle .mobile-menu, .navigation-branding img, .site-logo.mobile-header-logo img, .searchandoffer').show();
              });


            function contactsafari() {
                $('.contactsafari select#input_1_13').on('change', function(){
                 var val = $('#field_1_13 #input_1_13').val();
                 $('#field_1_14 #input_1_14').empty();

                   $.ajax({
                       url: '/wp-admin/admin-ajax.php',
                       type: 'POST',
                       data: 'action=qt_populate_trips&trip_val=' + val,
                       success : function( response ){
                           console.log('succes');
                           $('#field_1_14 #input_1_14').append(response);

                       },
                       error : function(error){
                           console.log('error',error)
                       }
                   })
               });
            }
            contactsafari();

            function contactsafari1() {
                $('.contactsafari select#input_1_13').on('change', function(){
                 var val = $('#field_1_13 #input_1_13').val();
                 $('#field_1_28 #input_1_28').empty();

                   $.ajax({
                       url: '/wp-admin/admin-ajax.php',
                       type: 'POST',
                       data: 'action=qt_populate_tilkoeb&trip_val=' + val,
                       success : function( response ){
                           $('#field_1_28 #input_1_28').append(response);
                       },
                       error : function(error){
                           console.log('error',error)
                       }
                   })
               });
            }
            contactsafari1();

            $('.safariimg .slick-next, .safariimg .slick-prev').on('click', function() {
                var slickNumber = $('.slick-slide.slick-current.slick-active img').attr('data-id')
                var highlightNumber = $('.slick-slide.slick-current.slick-active img').parents('.safariimg').siblings('.safaritx').children('.safaricenter.second').children('.highlight[data-id='+slickNumber+']')
                if( slickNumber = highlightNumber) {
                    $(highlightNumber).addClass('current');
                    $(highlightNumber).siblings().each(function() {
                        $(this).removeClass('current')
                    })
                }
            })


            if($('.ture.current').attr('checked', true)){
              runAjax()
              }

})( jQuery )
lazySizes.init(); //fallback if img is above-the-fold
