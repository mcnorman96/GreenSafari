<?php
//Trips cpt
function create_trips_cpt() {
    $cpt = 'trips';
    $cpt_singular = 'Rejse';
    $cpt_plural = 'Rejser';

    $labels = array(
        'add_new_item' => __('Add New '.$cpt_singular,'bbh'),
        'add_new' => __( 'Add New','bbh'),
        'all_items' => __('All '.$cpt_plural,'bbh'),
        'edit_item' => __('Edit '.$cpt_singular,'bbh'),
        'name' => __($cpt_plural,'bbh'),
        'name_admin_bar' => __($cpt_singular,'bbh'),
        'new_item' => __('New '.$cpt_singular,'bbh'),
        'not_found' => __('No '.$cpt_singular.' found','bbh'),
        'not_found_in_trash' => __('No '.$cpt_plural.' found in Trash','bbh'),
        'parent_item_colon' => __('Parent '.$cpt_singular,'bbh'),
        'search_items' => __('Search '.$cpt_plural,'bbh'),
        'view_item' => __('View '.$cpt_singular,'bbh'),
        'view_items' => __('View '.$cpt_plural,'bbh'),
    );
    $args = array(
        'labels' => $labels,
        'supports' => array('thumbnail', 'title' ),
        'taxonomies' => array('rejsetype', 'rejsedestination'),
        'menu_icon' => 'dashicons-groups',
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 20,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'can_export' => true,
        'has_archive' => true,
        'hierarchical' => true,
        'exclude_from_search' => false,
        'show_in_rest' => true,
        'publicly_queryable' => true,
        'capability_type' => 'post',
        'rewrite' => array('slug' => 'safari'),
    );
    register_post_type($cpt, $args);
}
add_action( 'init', 'create_trips_cpt', 0 );
//employee rejsetype tax
function create_rejsetype_tax() {
    $tax = 'rejsetype';
    $tax_singular = 'Rejsetype';
    $tax_plural = 'Rejsetyper';

  $labels = array(
        'name'              => _x( $tax_plural, 'taxonomy general name', 'bbh' ),
    'singular_name'     => _x( $tax_singular, 'taxonomy singular name', 'bbh' ),
    'search_items'      => __( 'Search ' . $tax_plural, 'bbh' ),
    'all_items'         => __( 'All ' . $tax_plural, 'bbh' ),
    'parent_item'       => __( 'Parent ' . $tax_singular, 'bbh' ),
    'parent_item_colon' => __( 'Parent ' . $tax_singular . ':', 'bbh' ),
    'edit_item'         => __( 'Edit ' . $tax_singular, 'bbh' ),
    'update_item'       => __( 'Update ' . $tax_singular, 'bbh' ),
    'add_new_item'      => __( 'Add new ' . $tax_singular, 'bbh' ),
    'new_item_name'     => __( 'New '. $tax_singular .' name', 'bbh' ),
    'menu_name'         => __( $tax_singular, 'bbh' ),
  );
  $args = array(
    'labels' => $labels,
    'description' => __( '', 'bbh' ),
    'hierarchical' => true,
    'public' => true,
    'publicly_queryable' => true,
    'show_ui' => true,
    'show_in_menu' => true,
    'show_in_nav_menus' => true,
    'show_tagcloud' => true,
    'show_in_quick_edit' => true,
    'show_admin_column' => true,
    'show_in_rest' => true,
  );
  register_taxonomy( $tax, array('trips'), $args );

}

//employee rejsedestination tax
function create_rejsedestination_tax() {
    $tax = 'rejsedestination';
    $tax_singular = 'Rejsedestination';
    $tax_plural = 'Rejsedestinationer';

  $labels = array(
        'name'              => _x( $tax_plural, 'taxonomy general name', 'bbh' ),
    'singular_name'     => _x( $tax_singular, 'taxonomy singular name', 'bbh' ),
    'search_items'      => __( 'Search ' . $tax_plural, 'bbh' ),
    'all_items'         => __( 'All ' . $tax_plural, 'bbh' ),
    'parent_item'       => __( 'Parent ' . $tax_singular, 'bbh' ),
    'parent_item_colon' => __( 'Parent ' . $tax_singular . ':', 'bbh' ),
    'edit_item'         => __( 'Edit ' . $tax_singular, 'bbh' ),
    'update_item'       => __( 'Update ' . $tax_singular, 'bbh' ),
    'add_new_item'      => __( 'Add new ' . $tax_singular, 'bbh' ),
    'new_item_name'     => __( 'New '. $tax_singular .' name', 'bbh' ),
    'menu_name'         => __( $tax_singular, 'bbh' ),
  );
  $args = array(
    'labels' => $labels,
    'description' => __( '', 'bbh' ),
    'hierarchical' => true,
    'public' => true,
    'publicly_queryable' => true,
    'show_ui' => true,
    'show_in_menu' => true,
    'show_in_nav_menus' => true,
    'show_tagcloud' => true,
    'show_in_quick_edit' => true,
    'show_admin_column' => true,
    'show_in_rest' => true,
  );
  register_taxonomy( $tax, array('trips', 'tilkoeb'), $args );

}


add_action( 'init', 'create_rejsetype_tax' );
add_action( 'init', 'create_rejsedestination_tax' );

//Trips cpt
function create_tilkoeb_cpt() {
    $cpt = 'tilkoeb';
    $cpt_singular = 'Tilkøb';
    $cpt_plural = 'Tilkøb';

    $labels = array(
        'add_new_item' => __('Add New '.$cpt_singular,'bbh'),
        'add_new' => __( 'Add New','bbh'),
        'all_items' => __('All '.$cpt_plural,'bbh'),
        'edit_item' => __('Edit '.$cpt_singular,'bbh'),
        'name' => __($cpt_plural,'bbh'),
        'name_admin_bar' => __($cpt_singular,'bbh'),
        'new_item' => __('New '.$cpt_singular,'bbh'),
        'not_found' => __('No '.$cpt_singular.' found','bbh'),
        'not_found_in_trash' => __('No '.$cpt_plural.' found in Trash','bbh'),
        'parent_item_colon' => __('Parent '.$cpt_singular,'bbh'),
        'search_items' => __('Search '.$cpt_plural,'bbh'),
        'view_item' => __('View '.$cpt_singular,'bbh'),
        'view_items' => __('View '.$cpt_plural,'bbh'),
    );
    $args = array(
        'labels' => $labels,
        'supports' => array('thumbnail', 'title' ),
        'taxonomies' => array('rejsedestination'),
        'menu_icon' => 'dashicons-groups',
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 20,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'can_export' => true,
        'has_archive' => true,
        'hierarchical' => true,
        'exclude_from_search' => false,
        'show_in_rest' => true,
        'publicly_queryable' => true,
        'capability_type' => 'post',
    );
    register_post_type($cpt, $args);
}
add_action( 'init', 'create_tilkoeb_cpt', 0 );
