<?php


add_filter('gform_pre_render_1', 'qt_populate_destination');
function qt_populate_destination( $form ) {

    foreach ( $form['fields'] as &$field ) {

        if ( $field->id !=13 ) {
            continue;
        }

    global $wpdb;
    $terms = get_terms(array('taxonomy' => 'rejsedestination', 'hide_empty' => false));

        $choices = array();

        foreach ( $terms as $term ) {
            $choices[] = array(
                'text' => $term->name,
                'value' => $term->name,
                'isSelected' => false
            );
        }
        $field->choices = $choices;

    }

return $form;

}

add_action( 'wp_ajax_nopriv_qt_populate_trips', 'qt_populate_trips'); //keep for people who allow post before registration
add_action( 'wp_ajax_qt_populate_trips', 'qt_populate_trips');
//ajax callback function
function qt_populate_trips() {

    $args = array(
        'posts_per_page' => -1,
        'post_type' => 'trips',
        'orderby'        => 'title',
        'order'          => 'ASC',
        'suppress_filter' => false,
        'tax_query' => array(
            'relation' => 'AND',
        ),
    );

    if( isset( $_POST['trip_val'] ) && !empty( $_POST['trip_val'] )) : // $tax->name is equal to the name attribute of the input field
        $tax = array(
           'taxonomy' => 'rejsedestination',
           'field' => 'slug',
           'terms' => $_POST['trip_val'],
           'operator' => 'IN'
        );
        array_push($args['tax_query'], $tax);
    endif;

        $query = new WP_Query($args);
        $posts = $query->posts;
          //Creating drop down item.
          foreach ($posts as $post) {
            $option .= '<option value="'.$post->post_title.'">';
            $option .= $post->post_title;
            $option .= '</option>';
          }

           //   Adding other... item
          echo '<option selected="selected">Vælg safaritur</option>'.$option;
          wp_reset_postdata();

}

add_action( 'wp_ajax_nopriv_qt_populate_tilkoeb', 'qt_populate_tilkoeb'); //keep for people who allow post before registration
add_action( 'wp_ajax_qt_populate_tilkoeb', 'qt_populate_tilkoeb');
//ajax callback function
function qt_populate_tilkoeb() {

    $args1 = array(
        'posts_per_page' => -1,
        'post_type' => 'tilkoeb',
        'orderby'        => 'title',
        'order'          => 'ASC',
        'suppress_filter' => false,
        'tax_query' => array(
            'relation' => 'AND',
        ),

    );

    if( isset( $_POST['trip_val'] ) && !empty( $_POST['trip_val'] )) : // $tax->name is equal to the name attribute of the input field
        $tax1 = array(
           'taxonomy' => 'rejsedestination',
           'field' => 'slug',
           'terms' => $_POST['trip_val'],
           'operator' => 'IN'
        );
        array_push($args1['tax_query'], $tax1);
    endif;

        $query1 = new WP_Query($args1);
        $posts = $query1->posts;
        $counter = 1;
          //Creating drop down item.
          foreach ($posts as $post) {
            $option1 .= '<li class="gchoice_1_28_'.$counter.'">';
            $option1 .= '<input name="input_28.'.$counter.'" type="checkbox" value="'.$post->post_title.'" id="choice_1_28_'.$counter.'">';
            $option1 .= '<label for="choice_1_28_'.$counter.'" id="label_1_28_'.$counter.'">'.$post->post_title.'</label>';
            $option1 .= '</li>';
          $counter++;
          }
           //   Adding other... item
          echo $option1;
          wp_reset_postdata();

          wp_die();
}


//add_filter('gform_pre_render_1', 'qt_populate_tilkoebs');
function qt_populate_tilkoebs( $form ) {

    foreach ( $form['fields'] as &$field ) {

        if ( $field->id !=28 ) {
            continue;
        }

        $posts = get_posts(array(
            'posts_per_page' => -1,
            'post_type' => 'tilkoeb'
        ));


        $choices = array();

        foreach ( $posts as $post ) {
            $choices[] = array(
                'text' => $post->post_title,
                'value' => $post->post_title,
                'isSelected' => false
            );
        }

        $field->choices = $choices;

    }

return $form;

}
