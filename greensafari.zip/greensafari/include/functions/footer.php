<?php
if ( ! defined( 'ABSPATH' ) ) exit;

add_action('generate_before_footer', 'bbh_custom_subfooter');

function bbh_custom_subfooter() {
        $text1= get_field('tx_left','options');
        $text2 = get_field('tx_middle', 'options');
        $text3= get_field('tx_right', 'options');
        $logo= get_field('logo','options');
        $textfooter = get_field('footer_tx', 'options');
        $cta = get_field('ctafooter', 'options');
        $contactformtx = get_field ('contactformtext', 'options');
        $ctaleft = get_field ('cta_left', 'options');
        $img = get_field('bg', 'options')


	?>


	<div class="bbh-outer-wrapper" id="bbh-subfooter">
			<div class="flexible-field-wrapper">
        <section class="flexible-inner-section bbh-inner-section footer has-padding">
          <img class="bg lazyload" src="<?php echo $img['sizes']['large']; ?>">
          <div class="grid-container second">
            <div class="row">
              <div class="col-md-4">
                <div class="footertx">
                  <?php echo $text1 ?>
                </div>
                <?php if( have_rows('kontaktinformation', 'options') ):
                    // loop through the rows of data
                    while ( have_rows('kontaktinformation', 'options') ) : the_row();
                        $icon = get_sub_field('icon');
                        $footertext = get_sub_field('contact_tx');
                        ?>
                        <div class="footerct">
                          <span class="<?php echo $icon ?>"></span>
                            <?php echo $footertext; ?>
                        </div>

                        <?php
                    endwhile;
                endif; ?>
              </div>
              <div class="col-md-4">
                <div class="footertx">
                  <?php echo $text2 ?>
                </div>
                <div class="footerflex">
                  <?php if( have_rows('information', 'options') ):
                      // loop through the rows of data
                      while ( have_rows('information', 'options') ) : the_row();
                          $informationlink = get_sub_field('link');
                          ?>
                          <a href="<?php echo $informationlink['url']; ?>"><div class="icon-pil-ned hoejre"></div><?php echo $informationlink['title']; ?></a>
                          <?php
                      endwhile;
                  endif; ?>

                </div>
              </div>
              <div class="col-md-4">
                <div class="footertx">
                  <?php echo $text3 ?>
                </div>
                  <div class="footersocials">
                    <?php if( have_rows('socials', 'options') ):
                        // loop through the rows of data
                        while ( have_rows('socials', 'options') ) : the_row();
                            $sociallink = get_sub_field('media');
                            $medielink = get_sub_field('medielink');
                            ?>
                            <a href="<?php echo $medielink; ?>"><span class="<?php echo $sociallink; ?>"></span></a>
                            <?php
                        endwhile;
                    endif; ?>
                  </div>
              </div>
            </div>
          </div>
          <div class="grid-container third">
            <div class="row">
              <div class="col-sm-12">
                <div class="footerlogo">
                  <img src="<?php echo $logo['sizes']['small'] ?>">
                </div>
                <div class="logotx">
                  <?php echo $textfooter ?>
                </div>
              </div>
            </div>
          </div>
        </section>


              <?php

					// save layout name as var
		            $slug = get_row_layout();
					// check if layout exist in import folder
					if( file_exists( get_theme_file_path("/include/flexible-content/import/{$slug}.php") ) ) {
		        		include( get_theme_file_path("/include/flexible-content/import/{$slug}.php") );
		        	}

		       ?>
			</div>

	</div>
	<?php
};
