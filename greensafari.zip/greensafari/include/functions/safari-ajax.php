<?php
add_action('wp_ajax_bbh_employee_ajax', 'bbh_employee_ajax'); // Change names according to your form
add_action('wp_ajax_nopriv_bbh_employee_ajax', 'bbh_employee_ajax'); // Change names according to your form

function bbh_employee_ajax(){
    //check for nonce security
    $nonce = $_POST['security'];

    if ( ! wp_verify_nonce( $nonce, 'bbh-employee-ajax-nonce' ) )
        die;

        $args = array(
            'post_type'              => 'trips',
            'posts_per_page'         => 6,
            'post_status'            => 'publish',
            'orderby'                => 'title',
            'order'                  => 'ASC',
            'paged'  => 1,
            'tax_query' => array(
            'relation' => 'AND',
    		),

        );


        if( isset( $_POST['rejsetype'] ) && !empty( $_POST['rejsetype'] )) : // $tax->name is equal to the name attribute of the input field
            $tax = array(
                'taxonomy' => 'rejsetype',
                'field' => 'term_id',
                'terms' => $_POST['rejsetype'],
                'operator' => 'IN'
            );
            array_push($args['tax_query'], $tax);
        endif;

        $query = new WP_Query($args);
        $postsdisplayed = $query->found_posts;

       ob_start(); ?>
       <div id="posts" data-count="<?php echo ceil($postsdisplayed); ?>"><?php
      if( $query->have_posts() ) :
  		while($query->have_posts()) : $query->the_post(); ?>
      <a href="<?php echo the_permalink() ?>">
        <div class="rejse">
            <div class="img lazyload" data-bgset="<?php echo get_the_post_thumbnail_url('','medium') ?>"></div>
            <div class="bg"></div>
            <div class="details">
                <h3 class="name">
                    <?php if(get_field('rejser_dage')) : ?><span class="days"><?php the_field('rejser_dage') ?> dage · </span><?php endif; ?>
                    <?php the_title(); ?>
                </h3>
                <?php if(get_field('safari_description')) : ?><span class="description"><?php the_field('safari_description') ?></span><?php endif; ?>
                <a href="<?php echo the_permalink() ?>"><span class="icon-pil-ned hoejre"></span>Undersøg safaritypen</a>
            </div>
        </div>
        </a>
        <?php endwhile; ?>
        <div class="placeholder"></div>
        <div class="placeholder"></div>
        <?php
		wp_reset_postdata();
	else :
		echo '<h3 class="no-matches">Ingen safarier</h3>';
	endif;
    ?> </div> <?php
	$trip_markup = ob_get_clean(); // Save person grid markup in output buffer

	$send = array(
		'trip_markup' => $trip_markup
	);
	wp_send_json($send); // Send json

	wp_die();
}


add_action('wp_ajax_bbh_employee_ajaxa', 'bbh_employee_ajaxa'); // Change names according to your form
add_action('wp_ajax_nopriv_bbh_employee_ajaxa', 'bbh_employee_ajaxa'); // Change names according to your form


function bbh_employee_ajaxa(){
    //check for nonce security
    $nonce = $_POST['security'];

    if ( ! wp_verify_nonce( $nonce, 'bbh-employee-ajaxa-nonce' ) )
        die;

        $args = array(
            'posts_per_page'         => 6,
            'post_type'              => 'trips',
            'post_status'            => 'publish',
            'orderby'                => 'title',
            'order'                  => 'ASC',
            'paged'  => 1,
            'tax_query' => array(
            'relation' => 'AND',
    		),

        );


        if( isset( $_POST['rejsedestination'] ) && !empty( $_POST['rejsedestination'] )) : // $tax->name is equal to the name attribute of the input field
            $tax = array(
                'taxonomy' => 'rejsedestination',
                'field' => 'term_id',
                'terms' => $_POST['rejsedestination'],
                'operator' => 'IN'
            );
            array_push($args['tax_query'], $tax);
        endif;

        $query = new WP_Query($args);
        $postsdisplayed = $query->found_posts;

       ob_start(); ?>
       <div id="posts" data-count="<?php echo ceil($postsdisplayed); ?>"><?php
      if( $query->have_posts() ) :
  		while($query->have_posts()) : $query->the_post(); ?>
      <a href="<?php echo the_permalink() ?>">
        <div class="rejse">
            <div class="img lazyload" data-bgset="<?php echo get_the_post_thumbnail_url('','medium') ?>"></div>
            <div class="bg"></div>
            <div class="details">
                <h3 class="name"><?php the_title(); ?></h3>
                <?php if(get_field('safari_description')) : ?><span class="description"><?php the_field('safari_description') ?></span><?php endif; ?>
                <a href="<?php echo the_permalink() ?>"><span class="icon-pil-ned hoejre"></span>Undersøg safaritypen</a>
            </div>
        </div>
        </a>
        <?php endwhile; ?>
        <div class="placeholder"></div>
        <div class="placeholder"></div>
        <?php
		wp_reset_postdata();
	else :
		echo '<h3 class="no-matches">Ingen safarier</h3>';
	endif;
    ?> </div> <?php
	$trip_markup = ob_get_clean(); // Save person grid markup in output buffer

	$send = array(
		'trip_markup' => $trip_markup
	);
	wp_send_json($send); // Send json

	wp_die();
}


add_action('wp_ajax_bbh_tilkoeb_ajax', 'bbh_tilkoeb_ajax'); // Change names according to your form
add_action('wp_ajax_nopriv_bbh_tilkoeb_ajax', 'bbh_tilkoeb_ajax'); // Change names according to your form


function bbh_tilkoeb_ajax(){
    //check for nonce security
    $nonce = $_POST['security'];

    if ( ! wp_verify_nonce( $nonce, 'bbh-tilkoeb-ajax-nonce' ) )
        die;

        $args = array(
            'post_type'              => 'tilkoeb',
            'posts_per_page'         => 6,
            'post_status'            => 'publish',
            'orderby'                => 'title',
            'order'                  => 'ASC',
            'paged'  => 1,
            'tax_query' => array(
            'relation' => 'AND',
    		),

        );


        if( isset( $_POST['rejsedestination'] ) && !empty( $_POST['rejsedestination'] )) : // $tax->name is equal to the name attribute of the input field
            $tax = array(
                'taxonomy' => 'rejsedestination',
                'field' => 'term_id',
                'terms' => $_POST['rejsedestination'],
                'operator' => 'IN'
            );
            array_push($args['tax_query'], $tax);
        endif;

        $query = new WP_Query($args);
        $postsdisplayed = $query->found_posts;

       ob_start(); ?>
       <div id="posts" data-count="<?php echo ceil($postsdisplayed); ?>"><?php
      if( $query->have_posts() ) :
  		while($query->have_posts()) : $query->the_post();?>
        <div class="rejse">
            <div class="img lazyload" data-bgset="<?php echo get_the_post_thumbnail_url('','medium') ?>"></div>
            <div class="bg"></div>
            <div class="details">
                <h3 class="name"><?php the_title(); ?></h3>
                <?php if(get_field('safari_description')) : ?><span class="description"><?php the_field('safari_description') ?></span><?php endif; ?>
                <a class="overlayphp"><span class="icon-pil-ned hoejre"></span>Undersøg safaritypen</a>
            </div>
            <div class="tilkoeboverlay">
                <div class="grid-container second">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="overlayheader">
                                <img class="lazyload" src="http://greensafari.byhand.nu/wp-content/uploads/2020/10/logo-green-safari-negativ.png" alt="">
                                <div class="overlayclose">
                                    <div class="icon-minus">

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="singlepost">
                    <div class="sektion two">
                        <div class="grid-container second">
                            <?php if( have_rows('tilkoeb_oversigt') ): ?>
                                 <?php while( have_rows('tilkoeb_oversigt') ): the_row();
                                    $safaritx = get_sub_field('txbox');
                                    $link = get_sub_field('link');
                                ?>
                            <div class="safarioversigt">
                                    <div class="safariimg">
                                    <?php
                                         // check if the repeater field has rows of data
                                         if( have_rows('imgs') ):
                                                 // loop through the rows of data
                                                 while ( have_rows('imgs') ) : the_row();
                                                 $safariimg = get_sub_field('img');
                                        ?>
                                         <img class="lazyload" src="<?php echo $safariimg['url']; ?>" alt="">
                                         <?php
                                                 endwhile;
                                         endif;
                                         ?>
                                    </div>
                                    <div class="safaritx">
                                        <div class="safaricenter">
                                            <?php
                                        echo $safaritx;
                                        if ($link):
                                            ?>
                                            <a class="btn" target="<?php echo $link['target'] ?>" href="<?php echo $link['url'] ?>"><?php echo $link['title'] ?></a>

                                            <?php
                                        endif;
                                        ?>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                        endwhile;
                                endif;
                                ?>
                            </div>
                    </div>
                    <div class="sektion one">
                        <div class="grid-container second">
                            <div class="row">
                                <div class="col-sm-8">
                                    <div class="tekstboks">
                                        <?php if(get_field('tilkob_tekst')) : ?><?php the_field('tilkob_tekst') ?><?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="highlights">
                                        <?php if(get_field('inklusiv_overskrift')) : ?><?php the_field('inklusiv_overskrift') ?><?php endif; ?>
                                        <?php
                                        // check if the repeater field has rows of data
                                        if( have_rows('tilkoeb_inklusiv') ):
                                            // loop through the rows of data
                                            while ( have_rows('tilkoeb_inklusiv') ) : the_row();
                                                $highlight = get_sub_field('tx');
                                                ?>
                                                <div class="highlight"><span class="icon-flueben"></span><?php echo $highlight; ?></div>
                                                <?php
                                            endwhile;
                                        endif;
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
        <div class="placeholder"></div>
        <div class="placeholder"></div>
        <?php
		wp_reset_postdata();
	else :
		echo '<h3 class="no-matches">Ingen tilkøb</h3>';
	endif;
    ?> </div> <?php
	$trip_markup = ob_get_clean(); // Save person grid markup in output buffer

	$send = array(
		'trip_markup' => $trip_markup
	);
	wp_send_json($send); // Send json

	wp_die();
}
