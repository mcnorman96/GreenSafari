<?php 
add_action( 'wp_ajax_my_action', 'my_action' );
add_action( 'wp_ajax_nopriv_my_action', 'my_action' );

function my_action() {
    $args = array(
        'posts_per_page' => 6,
        'post_type'      => 'trips',
        'orderby'        => 'title',
        'order'          => 'ASC',
        'paged' => $_POST['page'],
        'tax_query' => array(
            'relation' => 'AND',
        ),

    );

    if( isset( $_POST['trip_ids'] ) && !empty( $_POST['trip_ids'] )) : // $tax->name is equal to the name attribute of the input field
        $tax = array(
		'taxonomy' => 'rejsetype',
           'field' => 'term_id',
           'terms' => $_POST['trip_ids'],
           'operator' => 'IN'
        );
        array_push($args['tax_query'], $tax);
    endif;


$query = new WP_Query($args);
$posts = $query->posts;
$postsdisplayed = $query->found_posts;

if($posts): ?>
    <?php
    if( $query->have_posts() ) :
       while($query->have_posts()) : $query->the_post(); ?>
        <div class="rejse">
            <div class="img lazyload" data-bgset="<?php echo get_the_post_thumbnail_url('','medium') ?>"></div>
            <div class="bg"></div>
                <div class="details">
                <h3 class="name"><?php the_title(); ?></h3>
                <?php if(get_field('safari_description')) : ?><span class="description"><?php the_field('safari_description') ?></span><?php endif; ?>
            </div>
        </div>
        <?php endwhile; ?>
        <div class="placeholder"></div>
        <div class="placeholder"></div>
        <?php
       wp_reset_postdata();
   else :
       echo '<h3 class="no-matches">No employees found.</h3>';
   endif;
?>
    <div class="placeholder"></div>
    <div class="placeholder"></div>

<?php endif;
?>

<?php

	wp_die(); // this is required to terminate immediately and return a proper response
}
