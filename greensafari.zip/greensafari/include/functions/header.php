<?php
if ( ! defined( 'ABSPATH' ) ) exit;



add_action('generate_inside_navigation', 'bbh_custom_subheader');

function bbh_custom_subheader() {
	?>
<div class="headerflex">
        <?php wp_nav_menu( array(
            'theme_location' => 'left-menu',
            'container' => 'div',
            'container_class' => 'main-nav',
            'container_id' => 'left-menu',
            'menu_class' => '',
            'fallback_cb' => 'generate_menu_fallback',
            'items_wrap' => '<ul id="%1$s" class="%2$s ' . join( ' ', generate_get_menu_class() ) . '">%3$s</ul>'
         ) ); ?>
        <?php generate_header_items(); ?>
        <?php wp_nav_menu( array(
            'theme_location' => 'right-menu',
            'container' => 'div',
            'container_class' => 'main-nav',
            'container_id' => 'right-menu',
            'menu_class' => '',
            'fallback_cb' => 'generate_menu_fallback',
            'items_wrap' => '<ul id="%1$s" class="%2$s ' . join( ' ', generate_get_menu_class() ) . '">%3$s</ul>'
         ) ); ?>

</div>
              <?php

					// save layout name as var
		            $slug = get_row_layout();
					// check if layout exist in import folder
					if( file_exists( get_theme_file_path("/include/flexible-content/import/{$slug}.php") ) ) {
		        		include( get_theme_file_path("/include/flexible-content/import/{$slug}.php") );
		        	}

		       ?>
	</div>
	<?php
};

if ( wp_is_mobile() ) :
    add_action('generate_inside_mobile_header', 'bbh_custom_subheaders');
else :
    add_action('generate_after_header_content', 'bbh_custom_subheaders');
endif;



function bbh_custom_subheaders() {
	?>

		<div class="searchandoffer">
			<a class="btn-yellow contactform">BESTIL TILBUD</a>
			<div class="search">
				<div class="icon-soeg">
				</div>
				<?php get_search_form(); ?>
			</div>
		</div>
		<div class="contactsafari">
			<div class="contactheader">
				<img class="header-image" alt="greensafari" src="http://greensafari.byhand.nu/wp-content/uploads/2020/12/logo-green-safari-e1608109591420.png" title="greensafari">
				<div class="icon-minus"></div>
			</div>
			<?php echo do_shortcode("[gravityform id=1 ajax=true]");?>
		</div>

              <?php

					// save layout name as var
		            $slug = get_row_layout();
					// check if layout exist in import folder
					if( file_exists( get_theme_file_path("/include/flexible-content/import/{$slug}.php") ) ) {
		        		include( get_theme_file_path("/include/flexible-content/import/{$slug}.php") );
		        	}

		       ?>
	</div>
	<?php
};
