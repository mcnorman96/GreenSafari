<?php
add_action( 'wp_enqueue_scripts', 'bbh_enqueue_scripts_styles' );

function bbh_enqueue_scripts_styles() {
    /*----------  Scripts  ----------*/
    //Lazy sizes
    wp_enqueue_script( 'picturefill', get_stylesheet_directory_uri() . '/assets/js/lazysizes/picturefill.min.js' );
    wp_enqueue_script( 'lazysizes', get_stylesheet_directory_uri() . '/assets/js/lazysizes/lazysizes.min.js' );
    wp_enqueue_script( 'lazysizesbackground', get_stylesheet_directory_uri() . '/assets/js/lazysizes/ls.bgset.min.js' );
    //slick.js
    wp_enqueue_script( 'slickjs', get_stylesheet_directory_uri() . '/assets/js/slick/slick.min.js', array( 'jquery' )); // slickjs



	// enter-view.js
	wp_enqueue_script( 'bbh_enter_view', get_stylesheet_directory_uri() . '/assets/js/enter-view/enter-view.min.js', array(), '1.0.0', false);

	//bbh js
    wp_enqueue_script( 'brandbyhandscripts', get_stylesheet_directory_uri() . '/assets/js/bbh_scripts.js', array( 'jquery', 'bbh_enter_view' ), filemtime(STYLESHEETPATH . '/assets/js/bbh_scripts.js'), true );
    wp_localize_script( 'brandbyhandscripts', 'ajax_object',
                array( 'ajax_url' => admin_url( 'admin-ajax.php' ), 'we_value' => 1234 ) );
    //wp_enqueue_script( 'brandbyhandstandardscript', get_stylesheet_directory_uri() . '/assets/js/bbh_standards.js', array(), '1.0.0', false);
    /*----------  Styles  ----------*/
    //bootstrap
    wp_enqueue_style( 'bootstrapcss', get_stylesheet_directory_uri() . '/assets/bootstrap/bootstrap.css', '1.0', 'all');
    //slick
    wp_enqueue_style( 'slick', get_stylesheet_directory_uri() . '/assets/js/slick/slick.css', '1.0', 'all');
    wp_enqueue_style( 'slicktheme', get_stylesheet_directory_uri() . '/assets/js/slick/slick-theme.css', '1.0', 'all');

    //icomoon
    wp_enqueue_style('GreenSafariicomoon', 'https://i.icomoon.io/public/e9bd5dc1f6/GreenSafari/style.css', '1.0.0', 'all');

	// dequeue som gutenberg garbage
    wp_dequeue_style( 'wp-block-library' );
    wp_dequeue_style( 'wp-block-library-theme' );

	// dequeue child theme style, that we don't use
	wp_dequeue_style('generate-child');
}
