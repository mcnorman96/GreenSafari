<section class="flexible-inner-section bbh-inner-section">
    <div class="grid-container">
        <div class="row">
            <div class="col-sm-12">

            </div>
        </div>
    </div>
</section>
