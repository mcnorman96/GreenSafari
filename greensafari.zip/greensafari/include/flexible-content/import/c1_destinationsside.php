<?php

if ( ! defined( 'ABSPATH' ) ) exit;

$img = get_sub_field('bg');
$text = get_sub_field('destinationstx');
$link = get_sub_field('btn');

?>
<section class="flexible-inner-section has-padding bbh-inner-section c1-destinationsside" >
  <div class="voresturebg"></div>
        <div class="grid-container second">
            <div class="row">
                <div class="col-sm-6">
                    <?php echo $text; ?>
                </div>
              </div>
            <div class="row">
                <div class="col-sm-12">
                <div class="rejsers element-to-hide">
              <?php
                  $taxs = get_terms(array('taxonomy' => 'rejsedestination', 'hide_empty' => false));
                    $counter = 0;
                    foreach ( $taxs as $tax ) {
                    $imgs = get_field('rejsedestination_img', $tax); ?>
                      <div class="rejses">
                        <a href="<?php echo get_term_link( $tax ); ?>">
                          <div class="img lazyload" data-bgset="<?php echo $imgs['url'] ?>"></div>
                          <div class="bg"></div>
                              <div class="details">
                                  <h3 class="name"><?php echo $tax->name; ?></h3>
                                  <a href="<?php echo get_term_link( $tax ); ?>"><span class="icon-pil-ned hoejre"></span>Undersøg safaritypen</a>
                              </div>
                          </a>
                      </div>
                    <?php } ?>
              </div>
            </div>
        </div>
      </div>

</section>
