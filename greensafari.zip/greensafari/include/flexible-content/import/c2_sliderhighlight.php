<section class="flexible-inner-section has-padding bbh-inner-section sektion destinationeroversigt">
  <div class="grid-container">
    <div class="row">
      <div class="col-sm-12">
        <?php if( have_rows('rejsedestination_oplevelser') ): ?>
             <?php while( have_rows('rejsedestination_oplevelser') ): the_row();
          $safaritx = get_sub_field('txbox');
          $safaricta = get_sub_field('cta');
          $highlightCounter = 0;
          $imgCounter = 0;
          $highlightimg = get_sub_field('imgs');
          $firsthighlight = $highlightimg[0]['highlight'];
          ?>

        <div class="safarioversigt">
            <div class="safariimg">
              <?php
                 // check if the repeater field has rows of data
                 if( have_rows('imgs') ):
                     // loop through the rows of data
                     while ( have_rows('imgs') ) : the_row();
                     $safariimg = get_sub_field('img');

                ?>
                         <img class="lazyload" data-id="<?php echo $imgCounter; ?>" src="<?php echo $safariimg['url']; ?>" alt="">

                 <?php
 $imgCounter++;
                     endwhile;
                 endif;
                 ?>

            </div>
            <div class="safaritx">
              <div class="safaricenter second">
                <?php
              echo $safaritx;

              // check if the repeater field has rows of data
              if( have_rows('imgs') ):
                  // loop through the rows of data
                  while ( have_rows('imgs') ) : the_row();
                    $highlight = get_sub_field('highlight');
                      ?>
                      <div data-id="<?php echo $highlightCounter; ?>" class="highlight <?php if($highlight == $firsthighlight): echo "current"; endif; ?>">
    <span class="icon-stjerne"></span><?php echo $highlight; ?></div>
                      <?php
  $highlightCounter++;
                  endwhile;
              endif;
              ?>
              </div>
              </div>
        </div>

        <?php
            endwhile;
        endif;
        ?>
      </div>
    </div>
  </div>

</section>
