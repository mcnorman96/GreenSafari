<?php

if ( ! defined( 'ABSPATH' ) ) exit;

?>
<?php
    $cols       = intval(get_sub_field('cols'));
    $size       = get_sub_field('size');
    $background = get_sub_field('backgroundcolor');
    $text       = get_sub_field('text');
    $mg         = get_sub_field('mg');
    $txcolor = get_sub_field('txcolor');

    $section_background = 'style="background-color: '.$background.'; color: '.$txcolor.'"';


    $containerClass = $size == 'full' ? 'full' : 'grid-container';


    if (! function_exists('renderVariableContent')) {
        /**
        * Renders the content for this section
        *
        * @param $text wysiwyg field
        */
        function renderVariableContent($group){
            $bg = isset($group['color']) ? 'style="background-color: '.$group['color'].';"' : null;
            ?>
            <div class="single" <?php echo $bg ?>>
                <?php echo $group['text'] ?>
            </div>
            <?php
        }
    }
?>

<section class="flexible-inner-section bbh-inner-section variable-content <?php if($mg == 'no') { echo 'variable-mg'; } ?>" <?php echo $section_background ?>>
    <div class="outer-wrap <?php echo $containerClass ?>">
        <?php if($text): ?>
        <div class="top-text">
            <?php echo $text ?>
        </div>
        <?php endif; ?>
        <div class="inner-wrap cols-<?php echo $cols?>">

            <?php
            //For each col selected, we render the text from a col, called c1, c2, c3, c4
            for ( $i = 1; $i <= $cols; $i++ ) {
                $group = get_sub_field('c' . $i);
                renderVariableContent($group);
            }
            ?>
        </div>
    </div>
</section>
