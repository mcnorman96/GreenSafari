<?php
if ( ! defined( 'ABSPATH' ) ) exit;


 $tx1 = get_sub_field('tx1');
 $tx2 = get_sub_field('tx2');
 $tximg = get_sub_field('img');
?>

<section class="flexible-inner-section has-padding bbh-inner-section c2-tx-img" >
        <div class="grid-container">
            <div class="row">
                <div class="col-md-6">
                  <?php echo $tx1; ?>
                </div>
            </div>
            <div class="row">
              <div class="col-md-8">
                <br>
                  <?php echo $tx2; ?>
              </div>
                <img class="cirkelpng lazyload" src="<?php echo $tximg['url']; ?>" alt="">
            </div>
        </div>
</section>
