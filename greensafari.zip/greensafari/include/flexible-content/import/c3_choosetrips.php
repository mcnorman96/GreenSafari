<?php

if ( ! defined( 'ABSPATH' ) ) exit;

$text = get_sub_field('choosetxbox');
$link = get_sub_field('choosebutton');
$taxs = get_sub_field('choosetrips');

?>

<section class="flexible-inner-section has-padding bbh-inner-section c3-choosetrips" >
        <div class="grid-container second">
            <div class="row">
              <div class="flexcol">
                <div class="col-sm-6">
                    <?php echo $text; ?>
                </div>
                <div class="col-sm-6">
                    <a class="btn" target="<?php echo $link['target'] ?>" href="<?php echo $link['url'] ?>"><?php echo $link['title'] ?></a>
                </div>
              </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                  <div class="rejsers element-to-hide">
                    <?php

                    setup_postdata($taxs);
                    foreach ( $taxs as $tax ) {
                      $days = get_field('rejser_dage', $tax);
                      ?>

                          <div class="rejses">
                            <a href="<?php echo get_post_permalink($tax);?>">
                              <div class="img lazyload" data-bgset="<?php echo get_the_post_thumbnail_url($tax ,'medium');?> "></div>
                                <div class="bg"></div>
                                    <div class="details">
                                        <h3 class="name"><?php if($days){ echo $days." dage · "; } ?><?php echo $tax->post_title; ?></h3>
                                        <?php if($tax->safari_description) : ?><span class="description"><p><?php echo $tax->safari_description; ?></p></span><?php endif; ?>
                                        <a href="<?php echo get_post_permalink($tax);?>"><span class="icon-pil-ned hoejre"></span>Undersøg safaritypen</a>
                                    </div>
                            </a>
                          </div>
                        <?php
                    }
                    //}
                //} ?>
                  </div>
                </div>
            </div>
        </div>
      </div>
</section>
