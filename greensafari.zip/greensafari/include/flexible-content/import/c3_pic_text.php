<?php

if ( ! defined( 'ABSPATH' ) ) exit;

$headline = get_sub_field('texts');
$link = get_sub_field('btn');

?>

<section class="flexible-inner-section has-padding bbh-inner-section c3-pic-text" >
    <div class="grid-container">
        <div class="row">
            <div class="col-sm-12">
                <div class="text">
                    <?php echo $headline; ?>
                </div>
            </div>
            <?php
            // check if the repeater field has rows of data
            if( have_rows('imgs') ):
                // loop through the rows of data
                while ( have_rows('imgs') ) : the_row();
                    $img = get_sub_field('img');
                    $text = get_sub_field('text');
                    ?>
                    <div class="col-md-4">
                        <div class="lazyload">
                            <img src="<?php echo $img['sizes']['small']; ?>">
                            <div class="textbox">
                                <?php echo $text; ?>
                            </div>
                        </div>
                    </div>
                    <?php
                endwhile;
            endif;
            ?>
            <div class="col-sm-12">
                <a class="btn" target="<?php echo $link['target'] ?>" href="<?php echo $link['url'] ?>"><?php echo $link['title'] ?></a>
            </div>
        </div>
    </div>
</section>
