<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$chosenDestination = isset($_GET['destination']) ? $_GET['destination'] : '';
?>

<section class="flexible-inner-section has-padding bbh-inner-section c3-voresture" >
    <div class="voresturebg"></div>
        <div class="grid-container second">
            <div class="row">
                <div class="col-sm-12">
                    <?php
                    $args = array(
                        'posts_per_page' => 6,
                        'post_type'      => 'trips',
                        'orderby'        => 'title',
                        'order'          => 'ASC',
                        'paged' => 1,
                    );
                    $query = new WP_Query($args);
                    $postsdisplayed = $query->found_posts;
                    $posts = $query->posts;


                    if($posts):
                        $terms = get_terms(array('taxonomy'=>'rejsedestination','hide_empty'=>false)); ?>

                        <form action="<?php echo site_url() ?>/wp-admin/admin-ajax.php" method="post" id="filter">
                        
                          <div class="labels">


                            <label class="<?php if ($chosenDestination): echo ''; else: echo "current";  endif; ?>" id="resetform" for="">Alle
                                <input type="radio" name="rejsedestination" checked>
                            </label>
                            <?php foreach($terms as $term) : $termName = strtolower($term->name); ?>
                                <label for="<?php echo $term->term_id ?>" <?php if ($chosenDestination == $termName):
                                  echo "class='ture current'";
                                endif; ?>><?php echo $term->name ?>
                                    <input type="radio" value="<?php echo $term->term_id ?>" name="rejsedestination" id="<?php echo $term->term_id ?>" <?php if ($chosenDestination == $termName):
                                      echo "checked";
                                    endif; ?>>
                                  </label>

                                <?php endforeach; ?>
                            </div>

                                <input type="hidden" name="offset" value="0">
                                <input type="hidden" name="security" id="bbh-employee-ajaxa-nonce" value="<?php echo wp_create_nonce( 'bbh-employee-ajaxa-nonce' ) ?>"/>
                                <input type="hidden" name="action" value="bbh_employee_ajaxa">


                                <div class="rejser">
                                    <div id="posts" data-count="<?php echo ceil($postsdisplayed); ?>">
                                        <?php
                                        foreach($posts as $post):?>
                                        <?php setup_postdata($post);?>
                                        <div class="rejse">
                                          <a href="<?php echo the_permalink() ?>">
                                            <div class="img lazyload" data-bgset="<?php echo get_the_post_thumbnail_url('','medium') ?>"></div>
                                            <div class="bg"></div>
                                            <div class="details">
                                                <h3 class="name"><?php the_title(); ?></h3>
                                                <?php if(get_field('safari_description')) : ?><span class="description"><?php the_field('safari_description') ?></span><?php endif; ?>
                                                <a href="<?php echo the_permalink() ?>"><span class="icon-pil-ned hoejre"></span>Undersøg safaritypen</a>
                                            </div>
                                          </a>
                                        </div>
                                        <?php endforeach; ?>
                                        <?php wp_reset_postdata(); ?>
                                        <div class="placeholder"></div>
                                        <div class="placeholder"></div>
                                    </div>
                                </div>
                                <div id="load_more">
                                    <div class="icon-pil-ned"></div>
                                    <p>Indlæs flere</p>
                                </div>
                            </form>
                    <?php endif; ?>
                    <div class="ourtripscontact">
                        <?php
                        $ourtripstx = get_sub_field('ourtripstx');
                        $ourtripscta = get_sub_field('ourtripscta');
                         ?>
                         <?php echo $ourtripstx; ?>
                         <a class="btn-green" href="<?php echo $ourtripscta['url']; ?>"><?php echo $ourtripscta['title']; ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
