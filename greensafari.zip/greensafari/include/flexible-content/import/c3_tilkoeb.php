<?php
if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section class="flexible-inner-section has-padding bbh-inner-section c3-tilkoeb" >
    <div class="voresturebg"></div>
        <div class="grid-container second">
            <div class="row">
                <div class="col-sm-12">
                  <div class="tilkoebtx">
                      <?php
                      $tilkoebtx = get_sub_field('tilkoebtx');
                       ?>
                       <?php echo $tilkoebtx; ?>
                  </div>

                    <?php
                    $args = array(
                        'posts_per_page' => 6,
                        'post_type'      => 'tilkoeb',
                        'orderby'        => 'title',
                        'order'          => 'ASC',
                        'paged' => 1,
                    );
                    $query = new WP_Query($args);
                    $postsdisplayed = $query->found_posts;
                    $posts = $query->posts;
                    $counter = 0;

                    if($posts):
                        $terms = get_terms(array('taxonomy'=>'rejsedestination','hide_empty'=>false)); ?>

                        <form action="<?php echo site_url() ?>/wp-admin/admin-ajax.php" method="post" id="filter">
                                <div class="labels">
                                  <?php foreach($terms as $term) : ?>
                                      <label <?php if($counter == 0): echo 'class="current"'; endif; ?> for="<?php echo $term->term_id ?>"><?php echo $term->name ?>
                                        <input type="radio" value="<?php echo $term->term_id ?>" name="rejsedestination" id="<?php echo $term->term_id ?>"></label>
                                  <?php $counter++; endforeach; ?>
                                </div>
                                <input type="hidden" name="offset" value="0">
                                <input type="hidden" name="security" id="bbh-tilkoeb-ajax-nonce" value="<?php echo wp_create_nonce( 'bbh-tilkoeb-ajax-nonce' ) ?>"/>
                                <input type="hidden" name="action" value="bbh_tilkoeb_ajax">


                                <div class="rejser">
                                    <div id="posts" data-count="<?php echo ceil($postsdisplayed); ?>">
                                        <?php
                                        foreach($posts as $post):?>
                                        <?php setup_postdata($post);?>
                                        <div class="rejse">
                                            <div class="img lazyload" data-bgset="<?php echo get_the_post_thumbnail_url('','medium') ?>"></div>
                                            <div class="bg"></div>
                                            <a class="bookingcta" href="<?php get_permalink();?>">Gå direkte til booking</a>
                                            <div class="details">
                                                <h3 class="name"><?php the_title(); ?></h3>
                                                <?php if(get_field('safari_description')) : ?><span class="description"><?php the_field('safari_description') ?></span><?php endif; ?>
                                                <a class="overlayphp" ><span class="icon-pil-ned hoejre"></span>Undersøg safaritypen</a>
                                            </div>
                                            <div class="tilkoeboverlay">
                                                <div class="grid-container second">
                                                    <div class="row">
                                                        <div class="col-sm-12">
                                                            <div class="overlayheader">
                                                                <img class="lazyload" src="http://greensafari.byhand.nu/wp-content/uploads/2020/10/logo-green-safari-negativ.png" alt="">
                                                                <div class="overlayclose">
                                                                    <div class="icon-minus">

                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="singlepost">
                                                    <div class="sektion two">
                                                        <div class="grid-container second">
                                                            <?php if( have_rows('tilkoeb_oversigt') ): ?>
                                                                 <?php while( have_rows('tilkoeb_oversigt') ): the_row();
                                                                    $safaritx = get_sub_field('txbox');
                                                                    $link = get_sub_field('link');
                                                                ?>
                                                            <div class="safarioversigt">
                                                                    <div class="safariimg">
                                                                    <?php
                                                                         // check if the repeater field has rows of data
                                                                         if( have_rows('imgs') ):
                                                                                 // loop through the rows of data
                                                                                 while ( have_rows('imgs') ) : the_row();
                                                                                 $safariimg = get_sub_field('img');
                                                                        ?>
                                                                         <img class="lazyload" src="<?php echo $safariimg['url']; ?>" alt="">
                                                                         <?php
                                                                                 endwhile;
                                                                         endif;
                                                                         ?>
                                                                    </div>
                                                                    <div class="safaritx">
                                                                        <div class="safaricenter">
                                                                            <?php
                                                                        echo $safaritx;
                                                                        if ($link):
                                                                            ?>
                                                                            <a class="btn" target="<?php echo $link['target'] ?>" href="<?php echo $link['url'] ?>"><?php echo $link['title'] ?></a>

                                                                            <?php
                                                                        endif;
                                                                        ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <?php
                                                                        endwhile;
                                                                endif;
                                                                ?>
                                                            </div>
                                                    </div>
                                                    <div class="sektion one">
                                                        <div class="grid-container second">
                                                            <div class="row">
                                                                <div class="col-sm-8">
                                                                    <div class="tekstboks">
                                                                        <?php if(get_field('tilkob_tekst')) : ?><?php the_field('tilkob_tekst') ?><?php endif; ?>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-4">
                                                                    <div class="highlights">
                                                                        <?php if(get_field('inklusiv_overskrift')) : ?><?php the_field('inklusiv_overskrift') ?><?php endif; ?>
                                                                        <?php
                                                                        // check if the repeater field has rows of data
                                                                        if( have_rows('tilkoeb_inklusiv') ):
                                                                            // loop through the rows of data
                                                                            while ( have_rows('tilkoeb_inklusiv') ) : the_row();
                                                                                $highlight = get_sub_field('tx');
                                                                                ?>
                                                                                <div class="highlight"><span class="icon-flueben"></span><?php echo $highlight; ?></div>
                                                                                <?php
                                                                            endwhile;
                                                                        endif;
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <?php endforeach; ?>
                                        <?php wp_reset_postdata(); ?>
                                        <div class="placeholder"></div>
                                        <div class="placeholder"></div>
                                    </div>
                                </div>
                                <div id="load_more">
                                    <div class="icon-pil-ned"></div>
                                    <p>Indlæs flere</p>
                                </div>
                            </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
