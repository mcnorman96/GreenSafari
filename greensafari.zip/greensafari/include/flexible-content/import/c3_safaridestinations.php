<?php

if ( ! defined( 'ABSPATH' ) ) exit;

$img = get_sub_field('bg');
$text = get_sub_field('text');
$link = get_sub_field('btn');

?>
<section class="flexible-inner-section has-padding bbh-inner-section c3-safaridestinations" >
    <img class="bg lazyload" src="<?php echo $img['sizes']['large']; ?>">
        <div class="grid-container second">
            <div class="row">
              <div class="flexcol">
                <div class="col-sm-6">
                    <?php echo $text; ?>
                </div>
                <div class="col-sm-6">
                    <a class="btn contactform" target="<?php echo $link['target'] ?>" href="<?php echo $link['url'] ?>"><?php echo $link['title'] ?></a>
                </div>
              </div>

            </div>
            <div class="row">
                <div class="col-sm-12">

                <div class="rejsers element-to-hide">
              <?php
                  $taxs = get_terms(array('taxonomy' => 'rejsedestination', 'hide_empty' => false));
                    $counter = 0;
                    foreach ( $taxs as $tax ) {
                        $imgs = get_field('rejsedestination_img', $tax);
                        if ($counter < 3) {
                            ?>
                            <div class="rejses">
                              <a href="<?php echo get_term_link( $tax ); ?>">
                                <div class="img lazyload" data-bgset="<?php echo $imgs['url'] ?>"></div>
                                <div class="bg"></div>
                                    <div class="details">
                                        <h3 class="name"><?php echo $tax->name; ?></h3>
                                        <a href="<?php echo get_term_link( $tax ); ?>"><span class="icon-pil-ned hoejre"></span>Undersøg safaritypen</a>
                                    </div>
                                </a>
                            </div>
                            <?php
                        } else {
                            ?>
                              <div class="rejses showhide">
                                <a href="<?php echo get_term_link( $tax ); ?>">
                                  <div class="img lazyload" data-bgset="<?php echo $imgs['url'] ?>"></div>
                                  <div class="bg"></div>
                                      <div class="details">
                                          <h3 class="name"><?php echo $tax->name; ?></h3>
                                          <a href="<?php echo get_term_link( $tax ); ?>"><span class="icon-pil-ned hoejre"></span>Undersøg safaritypen</a>
                                      </div>
                                </a>
                              </div>
                            <?php
                        }
                      ?>
                        <?php
                        $counter++;
                    }

                ?>

              </div>
              <div id="loadmore">
                  <div class="icon-pil-ned"></div>
                  <p>Indlæs flere</p>
              </div>
            </div>
        </div>
        </div>

</section>
