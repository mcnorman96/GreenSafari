<?php
if ( ! defined( 'ABSPATH' ) ) exit;

?>
<?php
 $subpagebanner = get_sub_field('subpage_img');
 ?>

<div class="flexible-inner-section has-padding bbh-inner-section subpagebanner">
  <div class="singlebg"></div>
    <div class="subpagebannerbillede lazyload" data-bgset="<?php echo $subpagebanner['url'] ?>">
      <div class="imgbg"></div>
    </div>
  </div>
</div>
