<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$img = get_sub_field('bg');
$text = get_sub_field('text');
$link = get_sub_field('btn');

?>

<section class="flexible-inner-section has-padding bbh-inner-section c3-safari" >
    <img class="bg lazyload" src="<?php echo $img['sizes']['large']; ?>">
      <div class="grid-container second">
          <div class="row">
              <div class="col-sm-6">
                  <?php echo $text; ?>
              </div>
              <div class="col-sm-6">
                  <a class="btn" target="<?php echo $link['target'] ?>" href="<?php echo $link['url'] ?>"><?php echo $link['title'] ?></a>
              </div>
          </div>
          <div class="row">
              <div class="col-sm-12">
                  <?php
                  $args = array(
                      'posts_per_page' => 6,
                      'post_type'      => 'trips',
                      'orderby'        => 'title',
                      'order'          => 'ASC',
                      'paged' => 1,
                  );
                  $query = new WP_Query($args);
                  $postsdisplayed = $query->found_posts;
                  $posts = $query->posts;


                  if($posts):
                      $terms = get_terms(array('taxonomy'=>'rejsetype','hide_empty'=>false)); ?>

                      <form action="<?php echo site_url() ?>/wp-admin/admin-ajax.php" method="post" id="filter">
                        <div class="labels">

                          <label class="current" id="resetform" for="resetform">Alle
                              <input type="radio" name="resetform" id="resetform">
                          </label>
                          <?php foreach($terms as $term) : ?>
                              <label for="<?php echo $term->term_id ?>"><?php echo $term->name ?>
                                  <input type="radio" value="<?php echo $term->term_id ?>" name="rejsetype" id="<?php echo $term->term_id ?>"></label>
                              <?php endforeach; ?>

                            </div>
                              <input type="hidden" name="offset" value="0">
                              <input type="hidden" name="security" id="bbh-employee-ajax-nonce" value="<?php echo wp_create_nonce( 'bbh-employee-ajax-nonce' ) ?>"/>
                              <input type="hidden" name="action" value="bbh_employee_ajax">


                              <div class="rejser">
                                  <div id="posts" data-count="<?php echo ceil($postsdisplayed); ?>">
                                      <?php
                                      foreach($posts as $post):?>
                                      <?php setup_postdata($post);?>
                                      <div class="rejse">
                                        <a href="<?php echo the_permalink() ?>">
                                          <div class="img lazyload" data-bgset="<?php echo get_the_post_thumbnail_url('','medium') ?>"></div>
                                          <div class="bg"></div>
                                          <div class="details">
                                              <h3 class="name">
                                                  <?php if(get_field('rejser_dage')) : ?><span class="days"><?php the_field('rejser_dage') ?> dage · </span><?php endif; ?>
                                                  <?php the_title(); ?>
                                              </h3>
                                              <?php if(get_field('safari_description')) : ?><span class="description"><?php the_field('safari_description') ?></span><?php endif; ?>
                                              <a href="<?php echo the_permalink() ?>"><span class="icon-pil-ned hoejre"></span>Undersøg safaritypen</a>
                                          </div>
                                          </a>
                                      </div>
                                      <?php endforeach; ?>
                                      <?php wp_reset_postdata(); ?>
                                      <div class="placeholder"></div>
                                      <div class="placeholder"></div>
                                  </div>
                              </div>
                              <div id="load_more">
                                  <div class="icon-pil-ned"></div>
                                  <p>Indlæs flere</p>
                              </div>
                          </form>
                  <?php endif; ?>
              </div>
          </div>
      </div>

</section>
