<?php

if ( ! defined( 'ABSPATH' ) ) exit;

?>

<section class="flexible-inner-section has-padding bbh-inner-section c2-safarisupport">
    <div class="grid-container">
      <div class="row">
        <div class="col-sm-12">
          <h2>Hvilken skal din safari støtte?</h2>
          <?php if( have_rows('safarisupport') ): ?>
               <?php while( have_rows('safarisupport') ): the_row();
                  $supporttx = get_sub_field('txbox');
                  $supportimg = get_sub_field('img');
                  $supportunder = get_sub_field('txunder');
            ?>
            <?php echo $supporttx; ?>
          <div class="safarioversigt">
              <div class="safariimg">
                <img class="lazyload" src="<?php echo $supportimg['url']; ?>" alt="">
              </div>
              <div class="safaritx">
                <div class="safaricenter">
                  <?php
                //echo $supporttx;

                // check if the repeater field has rows of data
                if( have_rows('highlights') ):
                    // loop through the rows of data
                    while ( have_rows('highlights') ) : the_row();
                      $highlight = get_sub_field('tx');
                        ?>
                        <div class="highlight"><span class="icon-stjerne"></span><?php echo $highlight; ?></div>
                        <?php
                    endwhile;
                endif;
                ?>
                </div>
                </div>
          </div>
          <div class="imgtx">
            <?php echo $supportunder; ?>
          </div>

          <?php
              endwhile;
          endif;
          ?>
        </div>
      </div>
    </div>
</section>
