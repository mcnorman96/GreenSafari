<?php

if ( ! defined( 'ABSPATH' ) ) exit;

//$img = get_sub_field('img');
$text = get_sub_field('text');
$mbpic = get_sub_field('mobilepicture');
$video = get_sub_field('img');

//To get the ID between
function get_string_between($string, $start, $end){
$string = ' ' . $string;
$ini = strpos($string, $start);
if ($ini == 0) return '';
$ini += strlen($start);
$len = strpos($string, $end, $ini) - $ini;
return substr($string, $ini, $len);
}

// use preg_match to find iframe src
preg_match('/src="(.+?)"/', $video, $matches);
$src = $matches[1];
$videoID = get_string_between($matches[1], 'embed/', '?');

// add extra params to iframe src
$params = array(
'controls'    => 0,
'hd'        => 0,
'autoplay' => 1,
'playlist' => $videoID,
'loop' => 1,
'mute' => 1
);

$new_src = add_query_arg($params, $src);
$video = str_replace($src, $new_src, $video);

// add extra attributes to iframe html
$attributes = 'frameborder="0"';



$video = str_replace('></iframe>', ' ' . $attributes . '></iframe>', $video);



//

?>

<section class="flexible-inner-section bbh-inner-section c12-frontpagepicture">
    <div class="container-fluid">
        <div class="frontpagecontainer">
            <?php echo '<div class="video">'.$video.'</div>'; ?>
            <div class="mobilepicture">
                <img class="lazyload" src="<?php echo $mbpic['url']; ?>" alt="">
            </div>
            <div class="bg"></div>
            <div class="textbox">
                <?php echo $text ?>
                <div class="btns">
                    <?php
                    // check if the repeater field has rows of data
                    if( have_rows('btns') ):
                        // loop through the rows of data
                        while ( have_rows('btns') ) : the_row();
                            $link = get_sub_field('btn');
                            ?>
                            <a class="btn" target="<?php echo $link['target'] ?>" href="<?php echo $link['url'] ?>"><?php echo $link['title'] ?></a>
                            <?php
                        endwhile;
                    endif;
                    ?>
                </div>
            </div>
            <div class="icon-pil-ned"></div>
        </div>
    </div>
</section>
