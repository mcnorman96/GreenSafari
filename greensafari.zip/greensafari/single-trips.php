<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package GeneratePress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

get_header(); ?>

	<div id="primary" <?php generate_content_class();?>>
		<main id="main" <?php generate_main_class(); ?>>
			<?php
			/**
			 * generate_before_main_content hook.
			 *
			 * @since 0.1
			 */
			do_action( 'generate_before_main_content' );

			?>
				<div class="bbh-outer-wrapper" id="bbh-content">
					<?php
					if( have_rows('flex_content', 984) ): ?>

						<div class="flexible-field-wrapper">
							<?php // loop through the rows of data
							while ( have_rows('flex_content', 984) ) : the_row();

								// save layout name as var
								$slug = get_row_layout();
								// check if layout exist in import folder
								if( file_exists( get_theme_file_path("/include/flexible-content/import/{$slug}.php") ) ) {
									include( get_theme_file_path("/include/flexible-content/import/{$slug}.php") );
								}

							endwhile; // END while have_rows() ?>
						<?php // END div.flexible-field-wrapper ?>
					<?php else :
						// no layouts found
					endif;
					?>
					<?php
					$banner = get_field('rejser_bannerimg');
					$days = get_field('rejser_dage');
					$price = get_field('price');
					  ?>
					<div class="flexible-inner-section bbh-inner-section singleposts">
						<div class="singlebg"></div>
							<div class="rejsebannerbillede lazyload" data-bgset="<?php echo $banner['url'] ?>"><div class="imgbg"></div></div>
            					<?php
                    		$args = array(
                            'post_type'      => 'trips',
                        );
                        $query = new WP_Query($args);
                        $postsdisplayed = $query->found_posts;
                        $posts = $query->posts;

                        if($posts):
            					?>
            						<div class="singlepost">
                          <div class="sektion one">
														<div class="grid-container">
															<div class="row">
																<div class="col-sm-12">
																	<div class="rejsedage">
																		<p>
																		<?php if ($days): ?>
																			<?php echo $days.' DAGE'; ?>
																		<?php endif; ?>
																		<?php if ($price): ?>
																			<?php echo ' - '.$price.'kr'; ?>
																		<?php endif; ?>
																	 </p>
																	</div>
																		<h1><?php the_title(); ?></h1>
																</div>
	                                <div class="col-sm-6">
	                                    <div class="tekstboks">
	                                        <?php if(get_field('rejser_txbox')) : ?><span class="description"><?php the_field('rejser_txbox') ?></span><?php endif; ?>
	                                    </div>
	                                </div>
	                                <div class="col-sm-6">
																		<div class="highlights">
	                                    <?php
	                                    // check if the repeater field has rows of data
	                                    if( have_rows('rejser_highlight') ):
	                                        // loop through the rows of data
	                                        while ( have_rows('rejser_highlight') ) : the_row();
																						$highlight = get_sub_field('highlight');
	                                            ?>
	                                            <div class="highlight"><span class="icon-stjerne"></span><?php echo $highlight; ?></div>
	                                            <?php
	                                        endwhile;
	                                    endif;
	                                    ?>
																		</div>
	                            		</div>
																</div>
															</div>
                            </div>
                            <div class="sektion two">
															<div class="grid-container">

																<?php if( have_rows('rejser_safarioversigt') ): ?>
																     <?php while( have_rows('rejser_safarioversigt') ): the_row();
																	$safaritx = get_sub_field('txbox');
																	$link = get_sub_field('link');
																	?>

																<div class="safarioversigt">
																		<div class="safariimg">
																			<?php
																				 // check if the repeater field has rows of data
																				 if( have_rows('imgs') ):
																						 // loop through the rows of data
																						 while ( have_rows('imgs') ) : the_row();
																						 $safariimg = get_sub_field('img');
																				?>
																								 <img class="lazyload" src="<?php echo $safariimg['url']; ?>" alt="">

																				 <?php
																						 endwhile;
																				 endif;
																				 ?>

																		</div>
																		<div class="safaritx">
																			<div class="safaricenter">
																				<?php
																			echo $safaritx;
																			?>
																			<?php if ($link): ?>
																			<a class="btn contactform" target="<?php echo $link['target'] ?>" href="<?php echo $link['url'] ?>"><?php echo $link['title'] ?></a>
																			<?php endif; ?>
																			</div>
																			</div>
																</div>

																<?php
																		endwhile;
																endif;
																?>
															</div>
                            </div>
														<?php $programbg = get_field('programbg'); ?>
													<div class="sektion three">
														<img class="programbg lazyload" src="<?php echo $programbg['url']; ?>" alt="">
														<div class="grid-container">
															<?php if( have_rows('rejser_programoversigt') ): ?>
															     <?php while( have_rows('rejser_programoversigt') ): the_row();

															         // Get sub field values.
															         $headline = get_sub_field('headline');
																	 	?>
																		<div class="programoversigt">
																			<div class="row">
																				<div class="col-sm-12">
																					<div class="programheader">
																						<h2><?php echo $headline; ?></h2>
																					</div>

																					<div class="programcontent">
																						<?php
																			         // check if the repeater field has rows of data
																			         if( have_rows('program') ):
																			             // loop through the rows of data
																			             while ( have_rows('program') ) : the_row();
																			              $programheadline = get_sub_field('programheadline');
																						 		 		$programtx = get_sub_field('txbox');
																			                 ?>
																							 <div class="programmer">
																								 <div class="programcontentheader">
				    																				 	<h3><?php echo $programheadline; ?></h3><span id="icon" class="icon-plus"></span>
				    																			 </div>
				    																			 <div class="programcontentp">
				    																				<p><?php echo $programtx; ?></p>
				    																			 </div>
																							 </div>

																							 <?php
																			             endwhile;
																			         endif;
																			         ?>
																			 	</div>
																	 		</div>
																		</div>
																	 </div>
															     <?php endwhile; ?>
															 <?php endif; ?>
																</div>
                        </div>
												<div class="sektion four">
													<div class="grid-container">
														<div class="row">
															<div class="col-sm-12">
																<?php
																$loopcounter = 0;
																	 // check if the repeater field has rows of data
																	 if( have_rows('rejser_standard') ):
																		 // loop through the rows of data
																		 while ( have_rows('rejser_standard') ) : the_row();
																			$standardtx = get_sub_field('tx');
																			$counter = 1;
																			$counters = 1;
																 ?>
																 <div class="rejseovernatning">

																	 <div class="standardtx" >
																		 	<?php echo $standardtx; ?>
																	 </div>
																	 <div class="standardimgs">
																		 <?php
																				// check if the repeater field has rows of data
																				if( have_rows('slick_slider') ):
																					// loop through the rows of data
																					while ( have_rows('slick_slider') ) : the_row();
																					 $standardimg = get_sub_field('img');
																					 $imgtx = get_sub_field('tx');
																					 $int = $counter++;

																			?>
																					<div class="standardimg" data-number="<?php echo $int; ?>">
																					 <img class="lazyload" src="<?php echo $standardimg['sizes']['large']; ?>">
																					 <div class="imgtx">
																					 	<?php echo $imgtx; ?>
																					 </div>

																				 </div>
																			 <?php
																					 endwhile;
																			 endif;
																			 ?>
																	 </div>
																			 <?php
																					// check if the repeater field has rows of data
																					if( have_rows('slick_slider') ):
																						// loop through the rows of data
																						while ( have_rows('slick_slider') ) : the_row();

																						 $integer = $counters++;

																				?>

																				<div class="modal-slider" data-number="<?php echo $integer; ?>">
																					<div class="icon-minus">

																					</div>
																					<div class="inner-slider" >
																				<?php
																					 // check if the repeater field has rows of data
																					 if( have_rows('innerdias') ):
																						 // loop through the rows of data
																						 while ( have_rows('innerdias') ) : the_row();
																							$diasimg = get_sub_field('innerdia');

																				 ?>
																				 	<img class="lazyload" src="<?php echo $diasimg['sizes']['large']; ?>">
																				 <?php
																						 endwhile;
																				 endif;
																				 ?>
																				</div>
																			</div>
																			<?php
																					endwhile;
																			endif;
																			?>

																	 </div>
																 <?php
																		 endwhile;
																 endif;
																 ?>
															</div>
														</div>
														<div class="row">
															<div class="col-sm-12">
																<?php
																	 // check if the repeater field has rows of data
																	 if( have_rows('rejser_luksus') ):
																		 // loop through the rows of data
																		 while ( have_rows('rejser_luksus') ) : the_row();
																			$luksustx = get_sub_field('tx');
																			$counter2 = 1;
																			$counters2 = 1;
																 ?>
																 <div class="standardtx">
																	 	<?php echo $luksustx; ?>
																 </div>
																 <div class="standardimgs">
																	 <?php
																			// check if the repeater field has rows of data
																			if( have_rows('slick_slider') ):
																				// loop through the rows of data
																				while ( have_rows('slick_slider') ) : the_row();
																				 $standardimg2 = get_sub_field('img');
																				 $imgtx2 = get_sub_field('tx');
																				 $int2 = $counter2++;

																		?>
																				<div class="standardimg" data-number="<?php echo $int2; ?>">
																				 <img class="lazyload" src="<?php echo $standardimg2['sizes']['large']; ?>">
																				 <div class="imgtx">
																					<?php echo $imgtx2; ?>
																				 </div>
																			 </div>
																		 <?php
																				 endwhile;
																		 endif;
																		 ?>
																 </div>
																		 <?php
																				// check if the repeater field has rows of data
																				if( have_rows('slick_slider') ):
																					// loop through the rows of data
																					while ( have_rows('slick_slider') ) : the_row();

																					 $integer2 = $counters2++;

																			?>
																			<div class="modal-slider" data-number="<?php echo $integer2; ?>">
																				<div class="icon-minus">

																				</div>
																				<div class="inner-slider" >
																			<?php
																				 // check if the repeater field has rows of data
																				 if( have_rows('innerdias') ):
																					 // loop through the rows of data
																					 while ( have_rows('innerdias') ) : the_row();
																						$diasimg2 = get_sub_field('innerdia');

																			 ?>
																				<img class="lazyload" src="<?php echo $diasimg2['sizes']['large']; ?>">
																			 <?php
																					 endwhile;
																			 endif;
																			 ?>
																			</div>
																		</div>
																		<?php
																				endwhile;
																		endif;
																		?>
																 <?php
																		 endwhile;
																 endif;
																 ?>
															</div>
														</div>
													</div>
												</div>

												<div class="sektion five">
													<div class="grid-container">
														<div class="row">
															<div class="col-md-8">
																<h2>Inklusiv</h2>
																<div class="inklusiv">
																<?php
																	 if( have_rows('rejser_inklusiv') ):
																			 while ( have_rows('rejser_inklusiv') ) : the_row();
																				$inklusivtx = get_sub_field('tx');
																					 ?>

						 																	<p><span class="icon-flueben"></span><?php echo $inklusivtx; ?></p>

																	 <?php
																			 endwhile;
																	 endif;
																	 ?>
																 </div>
															</div>
															<div class="col-md-4">
																<h2>Eksklusiv</h2>
																<div class="eksklusiv">
																	<?php
																		 if( have_rows('rejser_eksklusiv') ):
																				 while ( have_rows('rejser_eksklusiv') ) : the_row();
																					$eksklusivtx = get_sub_field('tx');
																						 ?>
																								<p><span class="icon-minus"></span><?php echo $eksklusivtx; ?></p>
																		 <?php
																				 endwhile;
																		 endif;
																		 ?>
																	 </div>
															</div>
														</div>
													</div>
												</div>

												<div class="sektion six">
															<div class="col-md-6">
																<div class="rejser-priser">
																	<?php
																	$rejser_priser = get_field('rejser_priser');
																	echo $rejser_priser;
																						 ?>
																						 <a class="btn-green" href="/organisationer/">Se organisationerne</a>
																</div>
															</div>

															<div class="col-md-6">
																<div class="rejser-kontakt">
																	<?php
																	$rejser_kontakt = get_field('rejser_kontakt');
																	echo $rejser_kontakt;
																		 ?>
																		 <a class="btn-green contactform">Bestil tilbud</a>
																</div>
															</div>

												</div>
											</div>
                    <?php endif; ?>
							</div>
    				</div>
    			</div>
			<?php
			/**
			 * generate_after_main_content hook.
			 *
			 * @since 0.1
			 */
			do_action( 'generate_after_main_content' );
			?>
		</main><!-- #main -->
	</div><!-- #primary -->

	<?php
	/**
	 * generate_after_primary_content_area hook.
	 *
	 * @since 2.0
	 */
	do_action( 'generate_after_primary_content_area' );

	generate_construct_sidebars();


	get_footer();
