<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package GeneratePress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

get_header(); ?>

	<div id="primary" <?php generate_content_class();?>>
		<main id="main" <?php generate_main_class(); ?>>
			<?php
			/**
			 * generate_before_main_content hook.
			 *
			 * @since 0.1
			 */
			do_action( 'generate_before_main_content' );

			?>
				<div class="bbh-outer-wrapper" id="bbh-content">
					<?php
					if( have_rows('flex_content', 984) ): ?>

						<div class="flexible-field-wrapper">
							<?php // loop through the rows of data
							while ( have_rows('flex_content', 984) ) : the_row();

								// save layout name as var
								$slug = get_row_layout();
								// check if layout exist in import folder
								if( file_exists( get_theme_file_path("/include/flexible-content/import/{$slug}.php") ) ) {
									include( get_theme_file_path("/include/flexible-content/import/{$slug}.php") );
								}

							endwhile; // END while have_rows() ?>
						<?php // END div.flexible-field-wrapper ?>
					<?php else :
						// no layouts found
					endif;
					?>

					<div class="flexible-inner-section bbh-inner-section singleposts">
						<div class="singlebg"></div>
            					<?php
                    		$args = array(
                            'post_type'      => 'tilkoeb',
                        );
                        $query = new WP_Query($args);
                        $postsdisplayed = $query->found_posts;
                        $posts = $query->posts;

                        if($posts):
            					?>
        						<div class="singlepost">
									<div class="sektion two">
										<div class="grid-container">
											<?php if( have_rows('tilkoeb_oversigt') ): ?>
												 <?php while( have_rows('tilkoeb_oversigt') ): the_row();
													$safaritx = get_sub_field('txbox');
													$link = get_sub_field('link');
												?>
											<div class="safarioversigt">
													<div class="safariimg">
													<?php
														 // check if the repeater field has rows of data
														 if( have_rows('imgs') ):
																 // loop through the rows of data
																 while ( have_rows('imgs') ) : the_row();
																 $safariimg = get_sub_field('img');
														?>
														 <img class="lazyload" src="<?php echo $safariimg['url']; ?>" alt="">
														 <?php
																 endwhile;
														 endif;
														 ?>
													</div>
													<div class="safaritx">
														<div class="safaricenter">
															<?php
														echo $safaritx;
														?>
														<a class="btn" target="<?php echo $link['target'] ?>" href="<?php echo $link['url'] ?>"><?php echo $link['title'] ?></a>
														</div>
													</div>
												</div>
												<?php
														endwhile;
												endif;
												?>
											</div>
									</div>
                      				<div class="sektion one">
										<div class="grid-container">
											<div class="row">
				                                <div class="col-sm-6">
				                                    <div class="tekstboks">
														<?php if(get_field('tilkob_tekst')) : ?><?php the_field('tilkob_tekst') ?><?php endif; ?>
				                                    </div>
				                                </div>
				                                <div class="col-sm-6">
													<div class="highlights">
														<?php if(get_field('inklusiv_overskrift')) : ?><?php the_field('inklusiv_overskrift') ?><?php endif; ?>
														<?php
														// check if the repeater field has rows of data
														if( have_rows('tilkoeb_inklusiv') ):
															// loop through the rows of data
															while ( have_rows('tilkoeb_inklusiv') ) : the_row();
																$highlight = get_sub_field('tx');
																?>
																<div class="highlight"><span class="icon-flueben"></span><?php echo $highlight; ?></div>
																<?php
															endwhile;
														endif;
														?>
													</div>
			                            		</div>
											</div>
										</div>
                            		</div>
								</div>
                    	<?php endif; ?>
						</div>
    				</div>
    			</div>
			<?php
			/**
			 * generate_after_main_content hook.
			 *
			 * @since 0.1
			 */
			do_action( 'generate_after_main_content' );
			?>
		</main><!-- #main -->
	</div><!-- #primary -->

	<?php
	/**
	 * generate_after_primary_content_area hook.
	 *
	 * @since 2.0
	 */
	do_action( 'generate_after_primary_content_area' );

	generate_construct_sidebars();


	get_footer();
