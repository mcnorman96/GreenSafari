<?php
get_header();
global $wp_query;
?>
<div class="searchpage">
  <div class="grid-container">
    <div class="row">
      <div class="col-sm-12">
        <h1 class="search-title"> <?php echo $wp_query->found_posts; ?>
          <?php _e( 'Søgeresultater fundet for', 'locale' ); ?>: "<?php the_search_query(); ?>" </h1>


        <?php if ( have_posts() ) { ?>

            <ul>

            <?php while ( have_posts() ) { the_post(); ?>

               <li>
                 <a href="<?php echo get_permalink(); ?>">
                 <div class="searchimg">
                   <div class="searchbg"></div>
                   <?php  if(has_post_thumbnail()) {
                     the_post_thumbnail('medium');
                   } else { ?>
                       <img src="http://greensafari.byhand.nu/wp-content/uploads/2020/11/placeholder-video.jpg" class="attachment-medium size-medium wp-post-image" alt="" srcset="http://greensafari.byhand.nu/wp-content/uploads/2020/11/placeholder-video.jpg 440w, http://greensafari.byhand.nu/wp-content/uploads/2020/11/placeholder-video.jpg 420w" sizes="(max-width: 440px) 100vw, 440px">
                     <?php } ?>
                     <div class="searchdetails">
                       <h3>
                         <?php the_title();  ?>
                       </h3>
                       <div class="h-readmore"><span class="icon-pil-ned hoejre"></span> <a href="<?php the_permalink(); ?>">Læs mere her</a></div>
                     </div>
                 </div>
                 </a>
               </li>

            <?php } ?>
            </ul>
        <?php } ?>
      </div>
    </div>
  </div>
</div>
<?php get_footer(); ?>
