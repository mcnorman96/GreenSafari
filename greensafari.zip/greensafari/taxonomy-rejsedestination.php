<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package GeneratePress
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

get_header(); ?>

	<div id="primary" <?php generate_content_class();?>>
		<main id="main" <?php generate_main_class(); ?>>
			<?php
			/**
			 * generate_before_main_content hook.
			 *
			 * @since 0.1
			 */
			do_action( 'generate_before_main_content' );

			?>
				<div class="bbh-outer-wrapper" id="bbh-content">
					<?php
					if( have_rows('flex_content', 984) ): ?>

						<div class="flexible-field-wrapper">
							<?php // loop through the rows of data
							while ( have_rows('flex_content', 984) ) : the_row();

								// save layout name as var
								$slug = get_row_layout();
								// check if layout exist in import folder
								if( file_exists( get_theme_file_path("/include/flexible-content/import/{$slug}.php") ) ) {
									include( get_theme_file_path("/include/flexible-content/import/{$slug}.php") );
								}

							endwhile; // END while have_rows() ?>
						<?php // END div.flexible-field-wrapper ?>
					<?php else :
						// no layouts found
					endif;
					?>
					<?php
          $queried_object = get_queried_object();
          $taxonomy = $queried_object->taxonomy;
          $term_id = $queried_object->term_id;
          $banner = get_field('rejsedestination_banner', $taxonomy . '_' . $term_id);
          $velkommen = get_field('rejsedestination_txbox', $taxonomy . '_' . $term_id);
				  $velkommencta = get_field('rejsedestination_cta', $taxonomy . '_' . $term_id);
          $rejsekort = get_field('rejsedestination_rejsekort', $taxonomy . '_' . $term_id);
					  ?>
					<div class="flexible-inner-section bbh-inner-section singleposts">
						<div class="singlebg"></div>
							<div class="rejsebannerbillede lazyload" data-bgset="<?php echo $banner['url'] ?>"><div class="imgbg"></div></div>
    						<div class="singlepost">
                  <div class="sektion destinationervelkommen">
                    <div class="grid-container">
                      <div class="row">
                        <div class="col-md-6">
                          <?php
                            echo $velkommen;
                           ?>
                           <?php if ($velkommencta) {
                             ?>
                             <div class="cta">
                               <a class="btn-yellow" href="<?php echo $velkommencta['url'];  ?>"><?php echo $velkommencta['title']; ?></a>
                             </div>
                             <?php
                           } ?>

                        </div>
                        <div class="col-md-6">
                          <div class="rejsekort">
                            <img class="lazyload" src="<?php echo $rejsekort['url']; ?>" alt="">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="sektion destinationeroversigt">
                    <div class="grid-container">
                      <div class="row">
                        <div class="col-sm-12">
                          <?php if( have_rows('rejsedestination_oplevelser', $taxonomy . '_' . $term_id) ): ?>
                               <?php while( have_rows('rejsedestination_oplevelser', $taxonomy . '_' . $term_id) ): the_row();
                            $safaritx = get_sub_field('txbox');
                            $safaricta = get_sub_field('cta');
														$highlightCounter = 0;
														$imgCounter = 0;
														$highlightimg = get_sub_field('imgs');
														$firsthighlight = $highlightimg[0]['highlight'];
                            ?>

                          <div class="safarioversigt">
                              <div class="safariimg">
                                <?php
                                   // check if the repeater field has rows of data
                                   if( have_rows('imgs') ):
                                       // loop through the rows of data
                                       while ( have_rows('imgs') ) : the_row();
                                       $safariimg = get_sub_field('img');

                                  ?>
                                           <img class="lazyload" data-id="<?php echo $imgCounter; ?>" src="<?php echo $safariimg['url']; ?>" alt="">

                                   <?php
								   $imgCounter++;
                                       endwhile;
                                   endif;
                                   ?>

                              </div>
                              <div class="safaritx">
                                <div class="safaricenter second">
                                  <?php
                                echo $safaritx;

                                // check if the repeater field has rows of data
                                if( have_rows('imgs') ):
                                    // loop through the rows of data
                                    while ( have_rows('imgs') ) : the_row();
                                      $highlight = get_sub_field('highlight');
                                        ?>
                                        <div data-id="<?php echo $highlightCounter; ?>" class="highlight <?php if($highlight == $firsthighlight): echo "current"; endif; ?>">
											<span class="icon-stjerne"></span><?php echo $highlight; ?></div>
                                        <?php
										$highlightCounter++;
                                    endwhile;
                                endif;
                                ?>
                                </div>
                                </div>
                          </div>

                          <?php
                              endwhile;
                          endif;
                          ?>
                        </div>
                      </div>
                    </div>

                  </div>
                  <div class="sektion destinationerquery">
										<?php if( have_rows('rejsedestination_destinationer', $taxonomy . '_' . $term_id) ): ?>
												 <?php while( have_rows('rejsedestination_destinationer', $taxonomy . '_' . $term_id) ): the_row();
											$destinationheadline = get_sub_field('headline');
											?>
											<div class="grid-container">
												<div class="row">
													<div class="col-sm-12">
														<h2><?php echo $destinationheadline; ?></h2>
														<div class="destinationsmenuer">
															<div class="labels">

													<?php
													$destination = get_sub_field('destination');
													$first = $destination[0]['destinationsheadline'];
													$fir = preg_replace('/\s+/', '_', $first);

														 // check if the repeater field has rows of data
														 if( have_rows('destination') ):
																 // loop through the rows of data
																 while ( have_rows('destination') ) : the_row();
																 $destinationsheadline = get_sub_field('destinationsheadline');
																 $arr = preg_replace('/\s+/', '_', $destinationsheadline);

														?>
														<a data-id="<?php echo $arr; ?>" class="destinationmenu <?php if($destinationsheadline == $first){ echo "current"; }; ?>">
																<label ><?php echo $destinationsheadline; ?></label>
														</a>
														<?php
																endwhile;
														endif;
														?>

													</div>
													</div>
														</div>
													<?php
														 // check if the repeater field has rows of data
														 if( have_rows('destination') ):
																 // loop through the rows of data
																 while ( have_rows('destination') ) : the_row();
																 $destinationimg = get_sub_field('img');
																 $destinationtx = get_sub_field('txboks');
																 $destinationsheadline = get_sub_field('destinationsheadline');
																 $arr = preg_replace('/\s+/', '_', $destinationsheadline);
														?>
														<div data-id="<?php echo $arr; ?>" class="destinationsboks">
															<div class="col-md-6">
																<h3><?php echo $destinationsheadline; ?> </h3>
																	<?php echo $destinationtx; ?>

															</div>
															<div class="col-md-6">
																<img class="lazyload" src="<?php echo $destinationimg['url']; ?>" alt="">
															</div>
														</div>

														 <?php
																 endwhile;
														 endif;
														 ?>
												</div>
											</div>
										<?php
												endwhile;
										endif;
										?>
                  </div>
									<?php if( have_rows('rejsedestination_destinationsvideo', $taxonomy . '_' . $term_id) ):
											// loop through the rows of data
											while ( have_rows('rejsedestination_destinationsvideo', $taxonomy . '_' . $term_id) ) : the_row();
											$video = get_sub_field('video');
											$videolink = get_sub_field('link');
											$videotx = get_sub_field('txbox');
											//To get the ID between
											if($video):
												function get_string_between($string, $start, $end){
												$string = ' ' . $string;
												$ini = strpos($string, $start);
												if ($ini == 0) return '';
												$ini += strlen($start);
												$len = strpos($string, $end, $ini) - $ini;
												return substr($string, $ini, $len);
												}

												// use preg_match to find iframe src
												preg_match('/src="(.+?)"/', $video, $matches);
												$src = $matches[1];
												$videoID = get_string_between($matches[1], 'embed/', '?');

												// add extra params to iframe src
												$params = array(
												'controls'    => 0,
												'hd'        => 0,
												'autoplay' => 0,
												'playlist' => $videoID,
												'loop' => 1,
												'mute' => 0,
												'audio' => 1
												);

												$new_src = add_query_arg($params, $src);
												$video = str_replace($src, $new_src, $video);

												// add extra attributes to iframe html
												$attributes = 'frameborder="0"';
												$video = str_replace('></iframe>', ' ' . $attributes . '></iframe>', $video);

									?>
                  <div class="sektion destinationsvideo">

										<div class="grid-container">
											<div class="row">
												<div class="col-sm-12">
													<div class="destinationsflex">
														<div class="videotekst">
															<?php if ($videotx): ?>
															<div class="videocenter">
																	<?php echo $videotx; ?>

																<a class="btn-green" href="<?php echo $videolink['url'];  ?>"><?php echo $videolink['title']; ?></a>

															</div>
															<?php endif; ?>
														</div>
														<div class="destinationsvideoen">
																<?php echo '<div class="videoen">'.$video.'</div>'; ?>
														</div>
													</div>
												</div>
											</div>
										</div>
										<?php endif; ?>
										<?php
											 endwhile;
										endif;
										?>
                  </div>

									<div class="sektion populardestinations">
										<?php if( have_rows('populaere_ture', $taxonomy . '_' . $term_id) ):
												// loop through the rows of data
												while ( have_rows('populaere_ture', $taxonomy . '_' . $term_id) ) : the_row();
												$trips = get_sub_field('trips');
												$tripslink = get_sub_field('link');
												$tripstx = get_sub_field('txbox');
												$taxs = get_sub_field('trips');
										?>
										<div class="grid-container second">
											<div class="row">
												<div class="col-md-6">
													<?php echo $tripstx; ?>
												</div>
												<div class="col-md-6">
													<?php if ($tripslink):  $terms = get_query_var('term');?>
														<a class="btn-green" href="<?php echo $tripslink['url'];  ?>?destination=<?php echo $terms; ?>"><?php echo $tripslink['title']; ?></a>
													<?php endif; ?>
												</div>
												<div class="col-sm-12">
													<?php
													$terms = get_query_var('term');
				                    $args = array(
				                        'posts_per_page' => 3,
				                        'post_type'      => 'trips',
				                        'orderby'        => 'title',
				                        'order'          => 'ASC',
																'tax_query' => array(
		                                array(
		                                'taxonomy' => 'rejsedestination',
		                                'field'    => 'slug',
		                                'terms'    => $terms,
		                                       ),
		                               ),
				                        'paged' => 1,
				                    );

				                    $query = new WP_Query($args);
				                    $postsdisplayed = $query->found_posts;
				                    $posts = $query->posts;

														if($posts): ?>
	                          <div class="rejser">
	                              <div id="posts" data-count="<?php echo ceil($postsdisplayed); ?>">
	                                  <?php
	                                  foreach($posts as $post):?>
	                                  <?php setup_postdata($post);?>
	                                  <div class="rejse">
																			<a href="<?php echo the_permalink() ?>">
	                                      <div class="img lazyload" data-bgset="<?php echo get_the_post_thumbnail_url('','medium') ?>"></div>
	                                      <div class="bg"></div>
	                                      <div class="details">
	                                          <h3 class="name"><?php the_title(); ?></h3>
	                                          <?php if(get_field('safari_description')) : ?><span class="description"><?php the_field('safari_description') ?></span><?php endif; ?>
	                                          <a href="<?php echo the_permalink() ?>"><span class="icon-pil-ned hoejre"></span>Undersøg safaritypen</a>
	                                      </div>
																			</a>
	                                  </div>
	                                  <?php endforeach; ?>
	                                  <?php wp_reset_postdata(); ?>
	                                  <div class="placeholder"></div>
	                                  <div class="placeholder"></div>
	                              </div>
	                          </div>

				                    <?php endif;
													?>


												</div>
											</div>
										</div>

										<?php
											 endwhile;
										endif;
										?>
									</div>
                </div>
							</div>
    				</div>
    			</div>
			<?php
			/**
			 * generate_after_main_content hook.
			 *
			 * @since 0.1
			 */
			do_action( 'generate_after_main_content' );
			?>
		</main><!-- #main -->
	</div><!-- #primary -->

	<?php
	/**
	 * generate_after_primary_content_area hook.
	 *
	 * @since 2.0
	 */
	do_action( 'generate_after_primary_content_area' );

	generate_construct_sidebars();


	get_footer();
